CLGLST for MVS3.8J / Hercules                                               
=============================                                               


Date: 02/08/2025  Release V0R9M03
      07/01/2024  Release V0R9M02
      10/10/2022  Release V0R9M01
      02/10/2022  Release V0R9M00  **INITIAL software distribution
      09/11/2019  Release V0R5M00

*  Author:  Larry Belmontes Jr.
*           https://ShareABitofIT.net/CLGLST-in-MVS38J
*           Copyright (C) 2019-2025  Larry Belmontes, Jr.


----------------------------------------------------------------------
|    CLGLST       I n s t a l l a t i o n   R e f e r e n c e        |
----------------------------------------------------------------------

   The approach for this installation procedure is to transfer the
distribution content from your personal computing device to MVS with
minimal JCL and to continue the installation procedure using supplied
JCL from the MVS CNTL data set under TSO.

   Below are descriptions of ZIP file content, pre-installation
requirements (notes, credits) and installation steps.

Thanks!
-Larry Belmontes



----------------------------------------------------------------------
|    CLGLST       C h a n g e   H i s t o r y                        |
----------------------------------------------------------------------
*  MM/DD/CCYY Version  Name / Description                                       
*  ---------- -------  -----------------------------------------------          
*  02/08/2025 0.9.03   Larry Belmontes Jr.                                      
*                      - Correct initialization of LIST print counters
*                                                                               
*  07/01/2024 0.9.02   Larry Belmontes Jr.                                      
*                      - Use software HLQ of SHRABIT
*                      - Limit TSO status capture onto ISPF LOG
*                      - Correct line truncation value for ISPF LIST
*                      - Add function to display LOG and LIST       
*                        internal variable values (dev tool)       
*                      - Update CLSTIT print driver from CLIST to   
*                        COBOL using PUTLIST to issue LISTIT I/O       
*                                                                               
*  10/10/2022 0.9.01   Larry Belmontes Jr.                                      
*                      - Correct FREE statement to delete LOG dataset
*                      - Correct FREE statement to delete LST dataset
*                      - Display LOG/LST termination errors and wait
*                        on user response
*                      - Change delay to 0 seconds in LOG/LST
*                        termination processing
*                      - Removed utility, GETMSG, from distribution
*                        to isolate maintenance of utility;
*                        see README file for more information
*                                                                               
*  02/10/2022 0.9.00   Larry Belmontes Jr.                                      
*                      - Initial version released to MVS 3.8J                   
*                        hobbyist public domain
*                                                                               
*  09/11/2019 0.5.00   Larry Belmontes Jr.
*                      Initial prototyping and development
*                      w ISPF 2.x
*                                                                               
*
======================================================================
* I. C o n t e n t   o f   Z I P   F i l e                           |
======================================================================

o  $INST00.JCL          Define Alias for HLQ in Master Catalog

o  $INST01.JCL          Load CNTL data set from distribution tape

o  $RECVXMI.JCL         RECV370 Receive XMI SEQ to MVS PDSs

o  $RECVTSO.JCL         TSO Receive XMI SEQ to MVS PDSs

o  CLGLST.V0R9M03.HET   Hercules Emulated Tape (HET) multi-file volume
   volser=VS0903        containing software distribution library.

o  CLGLST.V0R9M03.XMI   XMIT file containing software distribution library.

o  DSCLAIMR.TXT         Disclaimer

o  PREREQS.TXT          Required user-mods

o  README.TXT           This File
   Note: See application web page for any updates to readme.txt


Note:   ISPF v2.0+ (ISPF-like product from Wally Mclaughlin) must be     
-----   installed under MVS 3.8J TSO including associated user-mods
        per ISPF Installation Pre-reqs.

Note:   Two user-mods, ZP60014 and ZP60038, are REQUIRED to process
-----   CLIST symbolic variables via the IKJCT441 API on MVS 3.8J before
        using this software.
        More information and download links at:
        http://www.prycroft6.com.au/vs2mods/

Note:   CUTIL00 is a TSO utility that performs various functions using
-----   CLIST variables and must be installed as a pre-requisite.  
        More information including current version download link at:
        https://www.shareabitofit.net/CUTIL00-for-MVS-3-8J/    

Note:   DELAY is a utility that 'sleeps' for a number of seconds and
-----   must be installed as a pre-requisite.
        DELAY may be available on MVS3.8J TK3 and TK4- systems.
        More information at:
        https://www.cbttape.org/cbtdowns.htm  FILE #547   

Note:   PRINTOFF (TSO CP) is a pre-requisite for this install
-----   and may be available on MVS3.8J TK3 and TK4- systems.          
        More information at:
        https://www.cbttape.org/cbtdowns.htm  FILE #325 
        - or -                                                  
        may be downloaded in a MVS 3.8J install-ready format from
        Jay Moseley's site:
        http://www.jaymoseley.com/hercules/cbt_ware/printoff.htm

Note:   GETMSG is a ISPF utility to fetch messages and store each
-----   message component in CLIST variables and must be installed
        as a pre-requisite.  
        More information including current version download link at:
        https://www.shareabitofit.net/GETMSG-in-MVS38J/    


======================================================================
* II. P r e - i n s t a l l a t i o n   R e q u i r e m e n t s      |
======================================================================

o  The Master Catalog name for HLQ aliases.

o  The Master Catalog password may be required for some installation
   steps.

o  If loading via tape files, device 480 is utilized.

o  DATASET List after distribution library load for reference purposes:

   DATA-SET-NAME------------------------------- VOLUME ALTRK USTRK ORG FRMT % XT
   SHRABIT.CLGLST.V0R9M03.ASM                   PUB006    10     1 PO  FB  10  1
   SHRABIT.CLGLST.V0R9M03.CLIST                 PUB006     2     1 PO  FB  50  1
   SHRABIT.CLGLST.V0R9M03.CNTL                  PUB006    20     5 PO  FB  25  1
   SHRABIT.CLGLST.V0R9M03.HELP                  PUB006     2     1 PO  FB  50  1
   SHRABIT.CLGLST.V0R9M03.ISPF                  PUB006    40    11 PO  FB  27  1
   SHRABIT.CLGLST.V0R9M03.MACLIB                PUB006     2     1 PO  FB  50  1
   **END**    TOTALS:      76 TRKS ALLOC        20 TRKS USED       6 EXTENTS    


   Confirm the TOTAL track allocation is available on your device.

   Note: A different DASD device type (e.g. 3380) may yield different usage.

o  TSO user-id with sufficient access rights to update SYS2.CMDPROC,
   SYS2.CMDLIB, SYS2.HELP, SYS2.LINKLIB and/or ISPF libraries.

o  For installations with a security system (e.g. RAKF), you MAY need to
   insert additional JOB statement information.

   //         USER=???????,PASSWORD=????????

o  Names of ISPCLIB (Clist), ISPMLIB (Message), ISPLLIB (Load) and/or
   ISPPLIB (Panel) libraries.

o  Download ZIP file to your PC local drive.

o  Unzip the downloaded file into a temp directory on your PC device.

o  Install pre-requisite (if any) software and/or user modifications.

o  JCL from your local device (after unzip) may be edited using
   Notepad or nano (based on you host OS) and submitted via TCP/IP
   sockets reader if your system configuration supports this option.
   This option can replace some copy-paste tasks during installation.
   For more information on submitting JCL to MVS 3.8J, see
   https://www.shareabitofit.net/submitting-jcl-to-mvs-3-8j/

o  For more information on SHRABIT software distribution library, see
   https://www.shareabitofit.net/shrabit-distributions-for-mvs38j/

o  For more information on SHRABIT software installation, see
   https://www.shareabitofit.net/shrabit-installations-for-mvs38j/


======================================================================
* III. I n s t a l l a t i o n   S t e p s                           |
======================================================================

+--------------------------------------------------------------------+
| Step 1. Determine software installation source                     |
+--------------------------------------------------------------------+
|         HET or XMI ?                                               |
+--------------------------------------------------------------------+


    a) Software can be installed from one of two sources, HET or XMI.

       - For tape installation (HET), proceed to STEP 3. ****

         or

       - For XMIT installation (XMI), proceed to next STEP.


+--------------------------------------------------------------------+
| Step 2. Load distribution source from XMI file                     |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.CLGLST.V0R9M03.CNTL($RECVXMI)          |
|         JCL Member: SHRABIT.CLGLST.V0R9M03.CNTL($RECVTSO)          |
+--------------------------------------------------------------------+


______________________________________________________________________
//RECV000A JOB (SYS),'Receive CLGLST XMI',        <-- Review and Modify
//             CLASS=A,MSGCLASS=X,REGION=0M,     <-- Review and Modify
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  JOB: $RECVXMI  Receive Application XMI Files        *
//* *                 using RECV370                        *
//* -------------------------------------------------------*
//RECV     PROC HLQ='SHRABIT.CLGLST',VRM=V0R9M03,TYP=XXXXXXXX,
//             DSPACE='(TRK,(10,05,40))',DDISP='(,CATLG,DELETE)',
//             DUNIT=DISK,DVOLSER=PUB006         <-- Review and Modify
//*
//RECV370  EXEC PGM=RECV370
//RECVLOG  DD  SYSOUT=*
//XMITIN   DD  DISP=SHR,DSN=&&XMIPDS(&TYP)
//SYSPRINT DD  SYSOUT=*
//SYSUT1   DD  DSN=&&SYSUT1,
//   UNIT=SYSALLDA,SPACE=(CYL,(10,05)),DISP=(,DELETE,DELETE) 
//SYSUT2   DD  DSN=&HLQ..&VRM..&TYP,DISP=&DDISP,
//   UNIT=&DUNIT,SPACE=&DSPACE,VOL=SER=&DVOLSER
//SYSIN    DD  DUMMY
//SYSUDUMP DD  SYSOUT=*
//         PEND
//*
//* -------------------------------------------------------*
//* Ensure parent HLQ alias is declared
//* -------------------------------------------------------*
//DEFALIAS EXEC PGM=IDCAMS 
//SYSPRINT DD  SYSOUT=*
//SYSIN    DD  *
 PARM GRAPHICS(CHAIN(SN))
 LISTCAT ALIAS  ENT(SHRABIT)

 /* Review and modify catalog name below */                    
 IF LASTCC NE 0 THEN -
    DEFINE ALIAS(NAME(SHRABIT) RELATE(SYS1.UCAT.MVS))                          
/*                                                                      
//*
//* -------------------------------------------------------*
//* RECV370 DVTOC Software Distribution                     
//* -------------------------------------------------------*
//XMIPDS   EXEC RECV,TYP=XMIPDS,DSPACE='(CYL,(10,05,10),RLSE)' 
//RECV370.XMITIN DD  DISP=SHR,DSN=your.transfer.xmi    <-- XMI File 
//RECV370.SYSUT2   DD  DSN=&&XMIPDS,DISP=(,PASS), 
//   UNIT=SYSDA,SPACE=&DSPACE
//*
//CNTL     EXEC RECV,TYP=CNTL
//RECV370.SYSUT2   DD   DDNAME=&TYP
//CNTL     DD  DSN=&HLQ..&VRM..CNTL,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(20,10,10)),
//             DISP=&DDISP   
//*
//HELP     EXEC RECV,TYP=HELP
//RECV370.SYSUT2   DD   DDNAME=&TYP
//HELP     DD  DSN=&HLQ..&VRM..HELP,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(02,02,02)),
//             DISP=&DDISP   
//*
//CLIST    EXEC RECV,TYP=CLIST
//RECV370.SYSUT2   DD   DDNAME=&TYP
//CLIST    DD  DSN=&HLQ..&VRM..CLIST,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(02,02,02)),
//             DISP=&DDISP   
//*
//ISPF     EXEC RECV,TYP=ISPF
//RECV370.SYSUT2   DD   DDNAME=&TYP
//ISPF     DD  DSN=&HLQ..&VRM..ISPF,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(40,05,10)),
//             DISP=&DDISP   
//*
//ASM      EXEC RECV,TYP=ASM
//RECV370.SYSUT2   DD   DDNAME=&TYP
//ASM      DD  DSN=&HLQ..&VRM..ASM,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(10,10,10)),
//             DISP=&DDISP   
//*
//MACLIB   EXEC RECV,TYP=MACLIB
//RECV370.SYSUT2   DD   DDNAME=&TYP
//MACLIB   DD  DSN=&HLQ..&VRM..MACLIB,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(02,02,02)),
//             DISP=&DDISP   
//
______________________________________________________________________
Figure 1a: $RECVXMI.JCL


______________________________________________________________________
//RECV000B JOB (SYS),'TSO RECEIVE XMI',          <-- Review and Modify
//             CLASS=A,MSGCLASS=X,REGION=0M,     <-- Review and Modify
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  JOB: $RECVTSO  TSO RECEIVE APPLICATION XMI FILES    *
//* *                 for CLGLST software distribution     *
//* -------------------------------------------------------*
//*
//*    This JOB executes two steps:
//*
//*     1) IDCAMS to ensure parent HLQ alias (SHRABIT) is
//*        defined on master catalog
//*        Note: Alias definition bypassed if alias already
//*        ----- defined.
//*
//*     2) Executes TSO in BATCH mode and issues  
//*        TSO RECEIVE commands to load the XMI distribution
//*        library (an XMI SEQ dataset) to a temporary PDS.
//*        Each software PDS is loaded from before deleting
//*        temporary PDS.
//*
//*
//*    This JCL may be modified to suit your installation
//*    needs.                                                
//*
//*    The TSO RECEIVE commands use INdataset, DAtaset, VOL,
//*    and NOPRompt parms.
//*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PROC: PBTSO                                         *
//* *       Batch TSO                                      *
//* *                                                      *
//* -------------------------------------------------------*
//PBTSO    PROC
//STEP01   EXEC PGM=IKJEFT01
//SYSPROC  DD  DISP=SHR,DSN=SYS2.CMDPROC           
//*STEPLIB  DD  DISP=SHR,DSN=SYS2.LINKLIB           
//SYSPRINT DD  SYSOUT=*
//SYSTSPRT DD  SYSOUT=*
//SYSTSIN  DD  DUMMY       Command Line Input
//*
//         PEND
//*
//* -------------------------------------------------------*
//* Ensure parent HLQ alias is declared
//* -------------------------------------------------------*
//DEFALIAS EXEC PGM=IDCAMS 
//SYSPRINT DD  SYSOUT=*
//SYSIN    DD  *
 PARM GRAPHICS(CHAIN(SN))
 LISTCAT ALIAS  ENT(SHRABIT)

 /* Review and modify catalog name below */                    
 IF LASTCC NE 0 THEN -
    DEFINE ALIAS(NAME(SHRABIT) RELATE(SYS1.UCAT.MVS))                          
/*                                                                      
//*
//* -------------------------------------------------------*
//* TSO RECEIVE CLGLST Software Distribution
//* -------------------------------------------------------*
//TSORCV   EXEC PBTSO
//* -------------------------------------------------------*
//* Review and Modify the DSN of the transferred XMI           <-----
//* used in the TSO RECEIVE SYSTSIN DD.                        <-----
//* -------------------------------------------------------*
//STEP01.SYSTSIN DD *
 /* Modify 'SHRABIT.' with your parent HLQ, if different      */    
 /* Modify 'your.transfer.xmi' with transferred XMI SEQ DSN   */    
 /* Modify 'volser' with VOLSER on your system                */    
RECEIVE IN('your.transfer.xmi')          -  
        DA('SHRABIT.CLGLST.V0R9M03.XMIPDS')   -  
        VOL(volser)              NOPROMPT   
 /* Receive CNTL                      */    
RECEIVE IN('SHRABIT.CLGLST.V0R9M03.XMIPDS(CNTL)') -  
        DA('SHRABIT.CLGLST.V0R9M03.CNTL')     -  
        VOL(volser)              NOPROMPT   
 /* Receive HELP                      */    
RECEIVE IN('SHRABIT.CLGLST.V0R9M03.XMIPDS(HELP)') -  
        DA('SHRABIT.CLGLST.V0R9M03.HELP')     -  
        VOL(volser)              NOPROMPT   
 /* Receive CLIST                     */    
RECEIVE IN('SHRABIT.CLGLST.V0R9M03.XMIPDS(CLIST)') -  
        DA('SHRABIT.CLGLST.V0R9M03.CLIST')    -  
        VOL(volser)              NOPROMPT   
 /* Receive ISPF                      */    
RECEIVE IN('SHRABIT.CLGLST.V0R9M03.XMIPDS(ISPF)') -  
        DA('SHRABIT.CLGLST.V0R9M03.ISPF')     -  
        VOL(volser)              NOPROMPT   
 /* Receive ASM                       */    
RECEIVE IN('SHRABIT.CLGLST.V0R9M03.XMIPDS(ASM)') -  
        DA('SHRABIT.CLGLST.V0R9M03.ASM')      -  
        VOL(volser)              NOPROMPT   
 /* Receive MACLIB                    */    
RECEIVE IN('SHRABIT.CLGLST.V0R9M03.XMIPDS(MACLIB)') - 
        DA('SHRABIT.CLGLST.V0R9M03.MACLIB')   -  
        VOL(volser)              NOPROMPT   
 /* Delete XMIPDS                     */    
DELETE  'SHRABIT.CLGLST.V0R9M03.XMIPDS'          
/*
//
______________________________________________________________________
Figure 1b: $RECVTSO.JCL


    a) Transfer CLGLST.V0R9M03.XMI to MVS using your 3270 emulator.

       Make note of the DSN assigned on MVS transfer.

       Use transfer IND$FILE options:

          NEW BLKSIZE=3200 LRECL=80 RECFM=FB
          - or -
          NEW BLKSIZE(3200) LRECL(80) RECFM(FB)

       Ensure the DSN on MVS exists with the correct DCB information:

          ORG=PS BLKSIZE=3200 LRECL=80 RECFM=FB


    b) If using RECV370 to load XMI,
       Copy and paste the $RECVXMI JCL to a PDS member, update JOB
       statement to conform to your installation standard.

          - or -

       If using TSO RECEIVE to load XMI,
       Copy and paste the $RECVTSO JCL to a PDS member, update JOB
       statement to conform to your installation standard.

    c) The first step ensures the HLQ alias is defined and the
       subsequent steps perform the XMI load.

       Review JCL and apply any modifications per your installation
       including the DSN assigned during the transfer above for
       the XMI file.

    d) Submit the job.

    e) Review job output for successful load of the following PDSs:

       SHRABIT.CLGLST.V0R9M03.ASM
       SHRABIT.CLGLST.V0R9M03.CLIST
       SHRABIT.CLGLST.V0R9M03.CNTL
       SHRABIT.CLGLST.V0R9M03.HELP
       SHRABIT.CLGLST.V0R9M03.ISPF
       SHRABIT.CLGLST.V0R9M03.MACLIB

    f) Subsequent installation steps will be submitted from members
       contained in the CNTL data set.

    g) Proceed to STEP 6.   ****


+--------------------------------------------------------------------+
| Step 3. Define Alias for HLQ CLGLST in MVS User Catalog            |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.CLGLST.V0R9M03.CNTL($INST00)           |
+--------------------------------------------------------------------+


______________________________________________________________________
//CLGLST00 JOB (SYS),'Def SHRABIT Alias',    <-- Review and Modify 
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  CLGLST for MVS3.8J TSO / Hercules                   *
//* *  JOB: $INST00  Define Alias for parent HLQ SHRABIT   *
//* *  Note: The master catalog password may be required   *
//* -------------------------------------------------------*
//DEFALIAS EXEC PGM=IDCAMS 
//SYSPRINT DD  SYSOUT=*
//SYSIN    DD  *
 PARM GRAPHICS(CHAIN(SN))
 LISTCAT ALIAS  ENT(SHRABIT)

 /* Review and Modify catalog name below */                    
 IF LASTCC NE 0 THEN -
    DEFINE ALIAS(NAME(SHRABIT) RELATE(SYS1.UCAT.MVS))                          
/*                                                                      
//
______________________________________________________________________
Figure 2: $INST00 JCL


    Note: This distribution is installed under the HLQ alias SHRABIT.


    $INST00 bypasses the DEFINE ALIAS action when the alias
    is already defined.

    a) Copy and paste the above JCL to a PDS member, update JOB
       statement to conform to your installation standard.

    b) Submit the job.

    c) Review job output for successful DEFINE ALIAS.

    Note: When $INST00 runs for the first time,
          Job step DEFALIAS returns RC=0004 due to LISTCAT ALIAS function
          completing with condition code of 4 and DEFINE ALIAS function
          completing with condition code of 0.

    Note: When $INST00 runs after the ALIAS is defined,
          Job step DEFALIAS returns RC=0000 due to LISTCAT ALIAS function
          completing with condition code of 0 and DEFINE ALIAS
          function being bypassed.


+--------------------------------------------------------------------+
| Step 4. Load CNTL data set from distribution tape                  |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.CLGLST.V0R9M03.CNTL($INST01)           |
+--------------------------------------------------------------------+


______________________________________________________________________
//CLGLST01 JOB (SYS),'Install CNTL PDS',     <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  CLGLST for MVS3.8J TSO / Hercules                   *
//* *  JOB: $INST01  Load CNTL PDS from distribution tape  *
//* *  Note: Uses tape drive 480                           *
//* -------------------------------------------------------*
//LOADCNTL PROC THLQ=CLGLST,TVOLSER=VS0903,
//   HLQ='SHRABIT.CLGLST',VRM=V0R9M03,
//   DDISP='(,CATLG,DELETE)',
//   TUNIT=480,DVOLSER=PUB006,DUNIT=DISK     <-- Review and Modify
//LOAD001  EXEC PGM=IEBCOPY                                           
//SYSPRINT DD  SYSOUT=*                                              
//INCNTL   DD  DSN=&THLQ..&VRM..CNTL.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(1,SL)                 
//CNTL     DD  DSN=&HLQ..&VRM..CNTL,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(20,10,10)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//         PEND                                                     
//STEP001  EXEC LOADCNTL                     Load CNTL PDS
//SYSIN    DD  *                                                        
    COPY INDD=INCNTL,OUTDD=CNTL 
//
______________________________________________________________________
Figure 3: $INST01 JCL


    a) Before submitting the above job, the distribution tape
       must be made available to MVS by issuing the following
       command from the Hercules console:

       DEVINIT 480 X:\dirname\CLGLST.V0R9M03.HET READONLY=1

       where X:\dirname is the complete path to the location
       of the Hercules Emulated Tape file.

    b) Issue the following command from the MVS console to vary
       device 480 online:

       V 480,ONLINE

    c) Copy and paste the above JCL to a PDS member, update JOB
       statement to conform to your installation standard.

       Review JCL and apply any modifications per your installation.

    d) Submit the job.

    e) Review job output for successful load of the CNTL data set.

    f) Subsequent installation steps will be submitted from members
       contained in the CNTL data set.


+--------------------------------------------------------------------+
| Step 5. Load Other data sets from distribution tape                |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.CLGLST.V0R9M03.CNTL($INST02)           |
+--------------------------------------------------------------------+


______________________________________________________________________
//CLGLST02 JOB (SYS),'Install Other PDSs',   <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  CLGLST for MVS3.8J TSO / Hercules                   *
//* *  JOB: $INST02  Load other PDS from distribution tape *
//* *  Tape Volume:  File 1 - CNTL                         *
//* *                File 2 - CLIST                        *
//* *                File 3 - HELP                         *
//* *                File 4 - ISPF                         *
//* *                File 5 - ASM                          *
//* *                File 6 - MACLIB                       *
//* *  Note: Default TAPE=480, DASD=DISK on PUB006         *
//* -------------------------------------------------------*
//LOADOTHR PROC THLQ=CLGLST,TVOLSER=VS0903,
//   HLQ='SHRABIT.CLGLST',VRM=V0R9M03,
//   DDISP='(,CATLG,DELETE)',
//   TUNIT=480,DVOLSER=PUB006,DUNIT=DISK     <-- Review and Modify
//LOAD02   EXEC PGM=IEBCOPY                                           
//SYSPRINT DD  SYSOUT=*                                              
//INCLIST  DD  DSN=&THLQ..&VRM..CLIST.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(2,SL)                   
//INHELP   DD  DSN=&THLQ..&VRM..HELP.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(3,SL)                   
//INISPF   DD  DSN=&THLQ..&VRM..ISPF.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(4,SL)                   
//INASM    DD  DSN=&THLQ..&VRM..ASM.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(5,SL)                   
//INMACLIB DD  DSN=&THLQ..&VRM..MACLIB.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(6,SL)   
//CLIST    DD  DSN=&HLQ..&VRM..CLIST,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(02,02,02)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//HELP     DD  DSN=&HLQ..&VRM..HELP,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(02,02,02)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//ISPF     DD  DSN=&HLQ..&VRM..ISPF,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(40,05,10)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//ASM      DD  DSN=&HLQ..&VRM..ASM,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(10,10,10)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//MACLIB   DD  DSN=&HLQ..&VRM..MACLIB,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(02,02,02)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//         PEND                                                         
//*
//STEP001  EXEC LOADOTHR                     Load ALL other PDSs
//SYSIN    DD  *                                                        
    COPY INDD=INCLIST,OUTDD=CLIST
    COPY INDD=INHELP,OUTDD=HELP
    COPY INDD=INISPF,OUTDD=ISPF
    COPY INDD=INASM,OUTDD=ASM
    COPY INDD=INMACLIB,OUTDD=MACLIB
//
______________________________________________________________________
Figure 4: $INST02 JCL


    a) Member $INST02 installs remaining data sets from distribution
       tape.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Before submitting the above job, the distribution tape
       must be made available to MVS by issuing the following
       command from the Hercules console:

       DEVINIT 480 X:\dirname\CLGLST.V0R9M03.HET READONLY=1

       where X:\dirname is the complete path to the location
       of the Hercules Emulated Tape file.

    d) Issue the following command from the MVS console to vary
       device 480 online:

       V 480,ONLINE

    e) Submit the job.

    f) Review job output for successful loads.


+--------------------------------------------------------------------+
| Step 6. FULL or UPGRADE Installation                               |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.CLGLST.V0R9M03.CNTL($UP0903)           |
+--------------------------------------------------------------------+


______________________________________________________________________
//CLGLST0U JOB (SYS),'Upgrade CLGLST',       <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  CLGLST for MVS3.8J TSO / Hercules                   *
//* *                                                      *
//* *  JOB: $UP0902  Upgrade CLGLST Software               *
//* *       Upgrade to release V0R9M02 from V0R9M01        *
//* *                                                      *
//* *  Review JCL before submitting!!                      *
//* -------------------------------------------------------*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PROC: PARTSISPF                                     *
//* *       Copy ISPF Parts                                *
//* *                                                      *
//* -------------------------------------------------------*
//PARTSI   PROC HLQ=MYHLQ,VRM=VXRXMXX,
//             CLIB='XXXXXXXX.ISPCLIB',    
//             MLIB='XXXXXXXX.ISPMLIB',    
//             PLIB='XXXXXXXX.ISPPLIB',   
//             SLIB='XXXXXXXX.ISPSLIB',   
//             TLIB='XXXXXXXX.ISPTLIB'    
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  ISPF Library Member Installation                    *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPF Libraries   *
//* *      - ISPCLIB, ISPMLIB, ISPPLIB, ISPSLIB, ISPTLIB   *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPxLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ISPFLIBS EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//ISPFIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//CLIBOUT  DD  DSN=&CLIB,DISP=SHR
//MLIBOUT  DD  DSN=&MLIB,DISP=SHR
//PLIBOUT  DD  DSN=&PLIB,DISP=SHR
//SLIBOUT  DD  DSN=&SLIB,DISP=SHR
//TLIBOUT  DD  DSN=&TLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//         PEND
//*
//* -------------------------------------------------------*
//* *  Update ISPF parts for this release distribution     *
//* -------------------------------------------------------*
//* *  Note: Duplicate members are over-written.           *
//* -------------------------------------------------------*
//*
//* *  - Install libraries marked...                       *
//* *    - Search for '<--TARGET'                          *
//* *    - Update install libraries per your               *
//* *      installation standard                           *
//*
//* -------------------------------------------------------*
//ISPFPRTS EXEC PARTSI,HLQ='SHRABIT.CLGLST',VRM=V0R9M02,
//         CLIB='XXXXXXXX.ISPCLIB',                <--TARGET
//         MLIB='XXXXXXXX.ISPMLIB',                <--TARGET
//         PLIB='XXXXXXXX.ISPPLIB',                <--TARGET
//         SLIB='XXXXXXXX.ISPSLIB',                <--TARGET
//         TLIB='XXXXXXXX.ISPTLIB'                 <--TARGET
//SYSIN    DD  *
   COPY INDD=((ISPFIN,R)),OUTDD=CLIBOUT
   SELECT MEMBER=CLSTIT
   COPY INDD=((ISPFIN,R)),OUTDD=MLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
   COPY INDD=((ISPFIN,R)),OUTDD=PLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
   COPY INDD=((ISPFIN,R)),OUTDD=SLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
   COPY INDD=((ISPFIN,R)),OUTDD=TLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
// 
______________________________________________________________________
Figure 5: $UP0903.JCL  Upgrade from previous version to V0R9M03

    a) If this is the INITIAL software distribution, proceed to STEP 7.

    b) This software may be installed in FULL or UPGRADE from a
       prior version.

    Note:  If the installed software version is NOT the most recent
    -----  PREVIOUS version, perform a FULL install.

    Note:  If the installed software version is customized, a manual
    -----  review and evaluation is suggested to properly incorporate
           customizations into this software distribution before
           proceeding with the installation.

           Refer to the $UPvrmm.JCL members for upgraded software
           components being installed.

    Note:  $UPvrmm.JCL members exist in each software version.
    -----  For example, V1R3M00 software contains $UP1300.JCL
                        to upgrade from previous V1R2M00 distribution.
           For example, V1R2M00 software contains $UP1200.JCL
                        to upgrade from previous V1R1M00 distribution.

    c) If a FULL install of this software distribution is elected
       regardless of previous version installed on your system,
       proceed to STEP 7.

    d) If this is an UPGRADE from the PREVIOUS version,
       execute the below JCL based on current installed version:

       - $UP0903 to upgrade to V0R9M03 from V0R9M02
       - $UP0902 to upgrade to V0R9M02 from V0R9M01
       - $UP0901 to upgrade to V0R9M01 from V0R9M00
       - V0R9M00 is initial release, thus, no updates available!

    e) After upgrade is applied, proceed to validation, STEP 11.


+--------------------------------------------------------------------+
| Step 7. Install TSO parts                                          |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.CLGLST.V0R9M03.CNTL($INST03)           |
+--------------------------------------------------------------------+


______________________________________________________________________
//CLGLST03 JOB (SYS),'Install TSO Parts',    <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  CLGLST for MVS3.8J TSO / Hercules                   *
//* *                                                      *
//* *  JOB: $INST03  Install TSO parts                     *
//* *                                                      *
//* *  Note: Duplicate members are over-written.           *
//* -------------------------------------------------------*
//STEP001  EXEC PGM=IEBCOPY                                           
//SYSPRINT DD  SYSOUT=*                                              
//INCLIST  DD  DSN=SHRABIT.CLGLST.V0R9M03.CLIST,DISP=SHR            
//INHELP   DD  DSN=SHRABIT.CLGLST.V0R9M03.HELP,DISP=SHR             
//OUTCLIST DD  DSN=SYS2.CMDPROC,DISP=SHR                               
//OUTHELP  DD  DSN=SYS2.HELP,DISP=SHR
//SYSIN    DD  *                                                        
    COPY INDD=((INCLIST,R)),OUTDD=OUTCLIST
    SELECT MEMBER=NO#MBR#                    /*dummy entry no mbrs! */
    COPY INDD=((INHELP,R)),OUTDD=OUTHELP
    SELECT MEMBER=NO#MBR#                    /*dummy entry no mbrs! */
/*                                                                  
//
______________________________________________________________________
Figure 6: $INST03 JCL


    a) Member $INST03 installs TSO component(s).

       Note:  If no TSO components are included for this distribution,
       -----  RC = 4 is returned by the corresponding IEBCOPY step.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Submit the job.

    d) Review job output for successful load(s).


+--------------------------------------------------------------------+
| Step 8. Install CLGLST Software                                    |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.CLGLST.V0R9M03.CNTL($INST04)           |
+--------------------------------------------------------------------+


______________________________________________________________________
//CLGLST04 JOB (SYS),'Install CLGLST',       <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  CLGLST for MVS3.8J TSO / Hercules                   *
//* *                                                      *
//* *  JOB: $INST04  Install CLGLST Software               *
//* *                                                      *
//* *  - Install libraries marked...                       *
//* *    - Search for '<--TARGET'                          *
//* *    - Update install libraries per your               *
//* *      installation standard                           *
//* *                                                      *
//* -------------------------------------------------------*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PROC: ASMLKED                                       *
//* *       Assembler Link-Edit                            *
//* *                                                      *
//* -------------------------------------------------------*
//ASML     PROC HLQ=WHATHLQ,VRM=VXRXMXX,VIO=VIO,
//             SYSPRM='',
//             ASMPARM='NODECK,LOAD,RENT,TERM,XREF', 
//             LNKPARM='MAP,LIST,LET,RENT,XREF',
//             MBR=WHOWHAT
//*
//ASM      EXEC PGM=IFOX00,
//             PARM='&ASMPARM&SYSPRM' 
//SYSGO    DD  DSN=&&LOADSET,DISP=(MOD,PASS),SPACE=(CYL,(1,1)),
//             UNIT=&VIO,DCB=(DSORG=PS,RECFM=FB,LRECL=80,BLKSIZE=800)
//SYSLIB   DD  DSN=SYS1.MACLIB,DISP=SHR
//         DD  DSN=SYS1.AMODGEN,DISP=SHR
//         DD  DSN=SYS2.MACLIB,DISP=SHR          ** YREG  **
//         DD  DDNAME=PVTMAC                     ** PVTMAC  **
//         DD  DSN=&HLQ..&VRM..MACLIB,DISP=SHR   * myMACLIB **
//PVTMAC   DD  DSN=SYS2.MACLIB,DISP=SHR          * placeholder*
//SYSTERM  DD  SYSOUT=*
//SYSPRINT DD  SYSOUT=*
//SYSPUNCH DD  DSN=NULLFILE
//SYSUT1   DD  UNIT=&VIO,SPACE=(CYL,(6,1))
//SYSUT2   DD  UNIT=&VIO,SPACE=(CYL,(6,1))
//SYSUT3   DD  UNIT=&VIO,SPACE=(CYL,(6,1))
//SYSIN    DD  DSN=&HLQ..&VRM..ASM(&MBR),DISP=SHR <--INPUT
//*
//LKED     EXEC PGM=IEWL,
//             PARM='&LNKPARM',
//             COND=(0,NE,ASM)
//SYSLIN   DD  DSN=&&LOADSET,DISP=(OLD,DELETE)
//         DD  DDNAME=SYSIN
//SYSLMOD  DD  DUMMY
//SYSPRINT DD  SYSOUT=*
//SYSUT1   DD  UNIT=&VIO,SPACE=(CYL,(5,2))
//SYSIN    DD  DUMMY
//*
//         PEND
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PROC: COBLKED                                       *
//* *       COBOL     Link-Edit                            *
//* *                                                      *
//* -------------------------------------------------------*
//COBL     PROC HLQ=WHATHLQ,VRM=VXRXMXX,
//             MBR=WHOWHAT,
//             CPARM1='LOAD,SUPMAP',                                
//             CPARM2='SIZE=2048K,BUF=1024K'                        
//*COB EXEC  PGM=IKFCBL00,REGION=4096K,                             
//*          PARM='LOAD,SUPMAP,SIZE=2048K,BUF=1024K'                
//COB      EXEC PGM=IKFCBL00,REGION=4096K,                             
//           PARM='&CPARM1,&CPARM2'                                 
//STEPLIB  DD  DUMMY
//SYSPRINT DD  SYSOUT=*                                             
//SYSPUNCH DD  DSN=NULLFILE
//SYSUT1   DD  UNIT=SYSDA,SPACE=(460,(700,100))                        
//SYSUT2   DD  UNIT=SYSDA,SPACE=(460,(700,100))                        
//SYSUT3   DD  UNIT=SYSDA,SPACE=(460,(700,100))                        
//SYSUT4   DD  UNIT=SYSDA,SPACE=(460,(700,100))                        
//SYSLIN   DD  DSNAME=&LOADSET,DISP=(MOD,PASS),UNIT=SYSDA,             
//             SPACE=(80,(500,100))                                 
//SYSLIB   DD  DSN=&HLQ..&VRM..ASM,DISP=SHR
//         DD  DSN=&HLQ..&VRM..MACLIB,DISP=SHR
//SYSIN    DD  DSN=&HLQ..&VRM..ASM(&MBR),DISP=SHR <--INPUT
//*
//LKED     EXEC PGM=IEWL,PARM='LIST,XREF,LET',
//             COND=(5,LT,COB),REGION=96K
//SYSLIN   DD  DSNAME=&LOADSET,DISP=(OLD,DELETE)                      
//         DD  DDNAME=SYSIN                                                
//SYSLMOD  DD  DUMMY                                        
//SYSLIB   DD  DUMMY                  
//SYSUT1   DD  UNIT=SYSDA,SPACE=(1024,(50,20))                         
//SYSPRINT DD  SYSOUT=*                                              
//SYSIN    DD  DUMMY
//*
//         PEND
//*
//* -------------------------------------------------------*
//* *  Assemble Link-Edit PUTLIST to ISPLLIB               *
//* -------------------------------------------------------*
//PUTLIST  EXEC  ASML,HLQ='SHRABIT.CLGLST',VRM=V0R9M03,MBR=PUTLIST,
//         PARM.ASM='NODECK,LOAD,TERM,XREF,RENT',
//**       PARM.LKED='MAP,LIST,LET,XREF'
//         PARM.LKED='MAP,LIST,LET,RENT,XREF,REUS,REFR'
//LKED.SYSLMOD DD  DISP=SHR,
//         DSN=XXXXXXXX.ISPLLIB(&MBR)                <-- TARGET
//*
//* -------------------------------------------------------*
//* *  Compile  Link-Edit PRTLST to ISPLLIB                *
//* -------------------------------------------------------*
//PRTLST   EXEC COBL,HLQ='SHRABIT.CLGLST',VRM=V0R9M03,MBR=PRTLST,
//         CPARM1='LIST,LOAD,NODECK,PMAP,DMAP,LIB' 
//COB.STEPLIB  DD DSN=SYS1.LINKLIB,DISP=SHR          <--Complr STEPLIB
//COB.SYSLIB   DD DISP=SHR,DSN=&HLQ..&VRM..MACLIB    <-- Copybooks LIB
//LKED.SYSLMOD DD DSN=XXXXXXXX.ISPLLIB(&MBR),        <-- TARGET
//          DISP=SHR
//LKED.SYSLIB  DD DSN=SYS1.COBLIB,DISP=SHR           <--Complr COBLIB
//             DD DSN=XXXXXXXX.ISPLLIB,DISP=SHR      <-- PUTLIST
//             DD DSN=ISP.V2R2M0.LLIB,DISP=SHR       <-- ISP SYS LLIB
//
______________________________________________________________________
Figure 7: $INST04 JCL


    a) Member $INST04 installs program(s).

       Note:  If no components are included for this distribution,
       -----  an IEFBR14 step is executed.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Submit the job.

    d) Review job output for successful completion.


+--------------------------------------------------------------------+
| Step 9. Install ISPF parts                                         |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.CLGLST.V0R9M03.CNTL($INST05)           |
+--------------------------------------------------------------------+


______________________________________________________________________
//CLGLST05 JOB (SYS),'Install ISPF Parts',   <-- Review and Modify 
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  CLGLST for MVS3.8J TSO / Hercules                   *
//* *                                                      *
//* *  JOB: $INST05  Install ISPF parts                    *
//* *                                                      *
//* *  Note: Duplicate members are over-written.           *
//* *                                                      *
//* *                                                      *
//* *  - Uses ISPF 2.1 product from Wally Mclaughlin       *
//* *  - Install libraries marked...                       *
//* *    - Search for '<--TARGET'                          *
//* *    - Update install libraries per your               *
//* *      installation standard                           *
//* -------------------------------------------------------*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PROC: PARTSISPF                                     *
//* *       Copy ISPF Parts                                *
//* *                                                      *
//* -------------------------------------------------------*
//PARTSI   PROC HLQ=MYHLQ,VRM=VXRXMXX,
//             CLIB='XXXXXXXX.ISPCLIB',    
//             MLIB='XXXXXXXX.ISPMLIB',    
//             PLIB='XXXXXXXX.ISPPLIB',   
//             SLIB='XXXXXXXX.ISPSLIB',   
//             TLIB='XXXXXXXX.ISPTLIB'    
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  CLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPCLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPCLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDCLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//CLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//CLIBOUT  DD  DSN=&CLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  MLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPMLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPMLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDMLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//MLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//MLIBOUT  DD  DSN=&MLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPPLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPPLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDPLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//PLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//PLIBOUT  DD  DSN=&PLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  SLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPSLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPSLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDSLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//SLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//SLIBOUT  DD  DSN=&SLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  TLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPTLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPTLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDTLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//TLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//TLIBOUT  DD  DSN=&TLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//         PEND
//*
//ISPF     EXEC PARTSI,HLQ='SHRABIT.CLGLST',VRM=V0R9M03,
//         CLIB='XXXXXXXX.ISPCLIB',                <--TARGET
//         MLIB='XXXXXXXX.ISPMLIB',                <--TARGET
//         PLIB='XXXXXXXX.ISPPLIB',                <--TARGET
//         SLIB='XXXXXXXX.ISPSLIB',                <--TARGET
//         TLIB='XXXXXXXX.ISPTLIB'                 <--TARGET
//ADDCLIB.SYSIN    DD  *                  CLIB
   COPY INDD=((CLIBIN,R)),OUTDD=CLIBOUT
   SELECT MEMBER=C$CLOGIT
   SELECT MEMBER=CLOGIT
   SELECT MEMBER=CLOG 
   SELECT MEMBER=CLLDFLT
   SELECT MEMBER=C$CLSTIT
   SELECT MEMBER=CLSTIT
   SELECT MEMBER=CLST 
   SELECT MEMBER=CLSTCHR
   SELECT MEMBER=CLOGLSTX
//ADDMLIB.SYSIN    DD  *                  MLIB
   COPY INDD=((MLIBIN,R)),OUTDD=MLIBOUT
   SELECT MEMBER=CLOG00
   SELECT MEMBER=CLOG01
   SELECT MEMBER=CLOG02
   SELECT MEMBER=CLOG03
   SELECT MEMBER=CLST00
   SELECT MEMBER=CLST01
   SELECT MEMBER=CLST02
   SELECT MEMBER=CLST03
//ADDPLIB.SYSIN    DD  *                  PLIB
   COPY INDD=((PLIBIN,R)),OUTDD=PLIBOUT
   SELECT MEMBER=HLLDFLT
   SELECT MEMBER=PLLDFLT
   SELECT MEMBER=HLLP01 
   SELECT MEMBER=PLLP01 
   SELECT MEMBER=HLLP02 
   SELECT MEMBER=PLLP02 
   SELECT MEMBER=HLSTCHR
   SELECT MEMBER=PLSTCHR
   SELECT MEMBER=HLOGV01
   SELECT MEMBER=PLOGV01
   SELECT MEMBER=HLSTV01
   SELECT MEMBER=PLSTV01
//ADDSLIB.SYSIN    DD  *                  SLIB
   COPY INDD=((SLIBIN,R)),OUTDD=SLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
//ADDTLIB.SYSIN    DD  *                  TLIB
   COPY INDD=((TLIBIN,R)),OUTDD=TLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
//
______________________________________________________________________
Figure 8: $INST05 JCL


    a) Member $INST05 installs ISPF component(s).

       Note:  If no ISPF components are included for this distribution,
       -----  RC = 4 is returned by the corresponding IEBCOPY step.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Review and update DD statements for ISPCLIB (clist),
       ISPMLIB (messages), and/or ISPPLIB (panel) library names.
       The DD statements are tagged with '<--TARGET'.

    d) Submit the job.

    e) Review job output for successful load(s).


+--------------------------------------------------------------------+
| Step 10. Install Other Software                                    |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.CLGLST.V0R9M03.CNTL($INST40)           |
+--------------------------------------------------------------------+


______________________________________________________________________
//CLGLST40 JOB (SYS),'Install Other Pgms',   <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  CLGLST for MVS3.8J TSO / Hercules                   *
//* *                                                      *
//* *  JOB: $INST40  Install Other Software                *
//* *       Install xxxxxx   Programs                      *
//* *                                                      *
//* *                                                      *
//* -------------------------------------------------------*
//*
//* -------------------------------------------------------*
//* *  IEFBR14                                             *
//* -------------------------------------------------------*
//DUMMY    EXEC PGM=IEFBR14
//SYSPRINT DD   SYSOUT=*
//*
// 
______________________________________________________________________
Figure 9: $INST40 JCL


    a) Member $INST40 installs additional software.

       Note:  If no other software is included for this distribution,
       -----  an IEFBR14 step is executed.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Submit the job.

    d) Review job output for successful completion.


+--------------------------------------------------------------------+
| Step 11. Validate CLOGIT and CLSTIT                                |
+--------------------------------------------------------------------+


    a) From the ISPF Main Menu, enter the following command:

       TSO %C$CLOGIT

    b) The CLIST will initiate tests including testing the GETMSG
       utility and display various messages before starting a browse
       session of the LOGIT data set.

       Below is a representative sample output from C$CLOGIT:

______________________________________________________________________
 *** C$CLOGIT IVP TESTING CLIST ***
 *** ISPF IS ACTIVE        ***
 *** TEST GETMSG UTILITY   ***                                                  
 MSGID='CLOG000', RC=0                                                          
 GETMSG VARIABLES DISPLAYED...                                                  
 ERRSM='WELCOME CLOGIT TEST MSG '                                               
 ERRLM='CLOG000  CLOGIT LONG MESSAGE TEXT IVP...                                
        '                                                                       
 ERRALRM='YES'                                                                  
 ERRHM='        '                                                               
 ERRTYPE='        '                                                             
 *** TEST CLOGIT, .......! ***
 *** BROWSE LOG DATA SET   ***
 ***
______________________________________________________________________
Figure 10a: Sample messages displayed on terminal from C$CLOGIT


    c) The sample LOGIT data set contents should appear as represented in
       the below browse session:

______________________________________________________________________
 userid.LOGIT.Dyyjjj.Thhmmss on TSO00A ------------------------- Line 1 Col 1 80
 Command ===>                                                  Scroll ===> CSR
1       10        20        30        40        50        60        70
A---+----+----+----+----+----+----+----+----+----+----+----+----+----+----+----+
1PAGE: 1
 MM/DD/CCYY HH:MM:SS ID PROCESS  DESCRIPTION
 mm/dd/ccyy hh:mm:ss __ LOGINIT  *** START OF ISPF SESSION LOG -----------------
 mm/dd/ccyy hh:mm:ss __ LOGINIT  JOB userid(TSU00598) EXECUTING
  .
 mm/dd/ccyy hh:mm:ss
 mm/dd/ccyy hh:mm:ss    IVP      IVP TEST 2
 mm/dd/ccyy hh:mm:ss AB IVP      IVP TEST 3 W ID
 mm/dd/ccyy hh:mm:ss MM LOG_MSGS CLOG000: WELCOME CLOGIT TEST MSG
                        LOG_MSGL CLOG000: CLOG000  CLOGIT LONG MESSAGE TEXT IVP.
 mm/dd/ccyy hh:mm:ss    LOG_MSGS CLOG008: CLOGIT SHORT MSG ONLY
______________________________________________________________________
Figure 10b: Sample browse session for LOGIT data set after IVP


    d) Validation for CLOGIT is complete.


    e) From the ISPF Main Menu, enter the following command:

       TSO %C$CLSTIT

    f) The CLIST will initiate tests including and display various
       messages before starting a browse session of the LISTIT
       LISTIT data set.

       New test cases may be added with new distributions.

       Below is a representative sample output from C$CLSTIT:

______________________________________________________________________
 *** C$CLSTIT IVP TESTING CLIST ***
 *** ISPF IS ACTIVE        ***
 *** IVP TEST CLSTIT ***
 1. IVP TEST START LINE
 LISTIT ON FILE ALLOC = 'IVP TEST ...'
 LISTIT ON FILE ALLOC AFTER TOP CC = '1IVP TEST ...'
 RC=0
 2. DEFAULT BLANK LINE
 RC=0
 3. TEXT LINE, TRIPLE SPACE
 RC=0
 4. BLANK LINE, DOUBLE SPACE, NEW PAGE
 RC=0
 5. MUTLI-LINE, DOUBLE SPACE
 RC=0
 6. MUTLI-LINE, CC PROVIDED, NEW PAGE
 RC=0
 7. MUTLI-LINE, CC PROVIDED
 RC=0
 *** BROWSE LOG DATA SET   ***
 ***
______________________________________________________________________
Figure 10c: Sample messages displayed on terminal from C$CLSTIT


    g) The sample LISTIT data set contents should appear as represented in
       the below browse session:

______________________________________________________________________
 userid.LISTIT.Dyyjjj.Thhmmss on TSO00A ------------------------ Line 1 Col 1 80
 Command ===>                                                  Scroll ===> CSR
1       10        20        30        40        50        60        70
A---+----+----+----+----+----+----+----+----+----+----+----+----+----+----+----+
1IVP TEST ...

-TRIPLE SPACE LINE

0LINE 1
0LINE 2
0LINE 3
0LINE 4
0LINE 5
0LINE 1
0LINE 2
0LINE 3
0LINE 4
0LINE 5
0ONE DOUBLE SPACED LINE TO LIST FILE
______________________________________________________________________
Figure 10d: Sample browse session for LISTIT data set after IVP


    h) Validation for CLSTIT is complete.


+--------------------------------------------------------------------+
| Step 12. Done                                                      |
+--------------------------------------------------------------------+


    a) Congratulations!

       You completed the installation for the CLOGIT and CLSTIT commands.

       At this point, the LOGIT data set is allocated, can perform
       writes to the LOGIT data set including logging of ISPF messages.

       The LISTIT data set is allocated, can perform writes to the
       LISTIT data set.


+--------------------------------------------------------------------+
| Step 13. Incorporate CLGLST into ISPF and ISPF Start-up Procedure  |
+--------------------------------------------------------------------+

    This step can be bypassed if this is NOT an INITIAL install.
    It is assumed this step was completed during the INITIAL install.

    Four integration modifications are necessary including additional
    validation to complete the CLGLST application installation.

    These activities are outlined as follows:


    -----------------------------------------------
    1) ISPF Log and List Defaults (PLLDFLT)
        - and -
       ISPF List Data Set Characteristics (PLSTCHR)
    -----------------------------------------------

    a) It is suggested reusing option 2 and 5 from the ISPF PARAMETER OPTIONS
       menu (ISPOP0, option =0) to select new panels (PLLDFLT and PLSTCHR).

    b) Create a copy of ISPOP0 in your application panel library
       instead of the ISPF system panel library to preserve the original
       system panel in addition to preserving your ISPOP0 changes
       when upgrading your ISPF system with a new version.

    c) Edit the copied version of ISPOP0 in your application panel library.

    d) Change the option lines as shown below to enable and display
       revised menu options:

       )BODY section:

       -- change line from --
       ^   2 ^LOG/LIST    - Specify ISPF log and list defaults

       -- to --
       %   2 +LOG/LIST    - Specify ISPF log and list defaults^(CLGLST)

       -- change line from --
       ^   5 ^LIST        - Specify list data set characteristics

       -- to --
       %   5 +LIST        - Specify list data set characteristics^(CLGLST)

    e) Add the 'NEW ENTRY' lines as shown below to process option 2 and 5:

       )PROC section:

         &ZSEL = TRANS(TRUNC(&ZCMD,'.')
                       1,'PGM(ISPOPT01)'
       /*              2,'PANEL(ISPOP02)'                */
                       2,'CMD(%CLLDFLT) NEWAPPL(ISP)'      <-- NEW ENTRY
                       .
                       .
       /*              5,'PANEL(ISPOP05)'                */
                       5,'CMD(%CLSTCHR) NEWAPPL(ISP)'      <-- NEW ENTRY
                       .
                       .
                     ' ',' '
                       *,'?' )
       )END

    f) Save SELECTION MENU panel (ISPOP0) changes.

    g) Type =0 in the COMMAND line and press ENTER.
       The revised menu items (2 and 5) should display.

    h) Type 2 in the COMMAND line and press ENTER.
       The new panel, PLLDFLT, should display.

    i) You are now ready to declare LOG and LIST default options.

    j) When complete, press ENTER to save default options.

    k) Appropriate confirmation message should display on originating panel.

    l) Declaring LOG and LIST default values is complete and validated.

    m) Type =0 in the COMMAND line and press ENTER.
       The revised menu item (5) should display.

    h) Type 5 in the COMMAND line and press ENTER.
       The new panel, PLSTCHR, should display.

    i) You are now ready to declare LIST Data Set Characteristics.

    j) When complete, press ENTER to save characteristics.

    k) Appropriate confirmation message should display on originating panel.

    l) Declaring LIST Data Set Characteristics is complete and validated.




    -------------------------------------------
    2) Process LOG data set during ISPF session
    -------------------------------------------

    a) From the ISPF Main Menu, enter the below command to ensure
       LOG data set is allocated with content by generating
       a LOG entry:

       TSO %CLOGIT TXT(''ENSURE LOG DATA SET IS OPEN'')

    b) From the ISPF Main Menu, enter the below command to browse
       LOG data set current content:

       TSO %CLOG B

       NOTE: CLOG command has several keyword options-
             BROWSE, QUIKPRT, DELETE, PRINT, KEEP
             Refer to CLOG CLIST or
             https://ShareABitofIT.net/CLGLST-in-MVS38J

    c) Press PF3 to exit browse session

    d) From the ISPF Main Menu, enter the below command to present
       the LOG data set disposition panel (PLLP01):

       TSO %CLOG

    e) The disposition panel includes default values declared
       earlier in the validation process.

    f) Type KS for the Process option to keep using the same LOG
       data set for subsequent logging activity.

    g) No other panel data is necessary for this request.
       However, you can change data and save for subsequent use.

    h) When complete, press ENTER to process LOG data set.

    i) Appropriate confirmation message should display on originating panel.

    j) Processing LOG data set is complete and validated.




    --------------------------------------------
    3) Process LIST data set during ISPF session
    --------------------------------------------

    a) From the ISPF Main Menu, enter the below command to ensure
       LIST data set is allocated with content by generating
       a LIST entry:

       TSO %CLSTIT TXT(''ENSURE LIST DATA SET IS OPEN'') LLEN(28)

    b) From the ISPF Main Menu, enter the below command to browse
       LIST data set current content:

       TSO %CLST B

       NOTE: CLST command has several keyword options-
             BROWSE, QUIKPRT, DELETE, PRINT, KEEP
             Refer to CLST CLIST or
             https://ShareABitofIT.net/CLGLST-in-MVS38J

    c) Press PF3 to terminate browse

    d) From the ISPF Main Menu, enter the below command to present
       the LIST data set disposition panel (PLLP02):

       TSO %CLST

    e) The disposition panel includes default values declared
       earlier in the validation process.

    f) Type KS for the Process option to keep using the same LIST
       data set for subsequent printing activity.

    g) No other panel data is necessary for this request.
       However, you can change data and save for subsequent use.

    h) When complete, press ENTER to process LIST data set.

    i) Appropriate confirmation message should display on originating panel.

    j) Processing LIST data set is complete and validated.




    ---------------------------------------------------------
    4) Process LOG and/or LIST data set after ISPF terminates
    ---------------------------------------------------------

    Note:  An alternative to implement this post-process is discussed
           on the SHRABIT website.  See following URLs:
           https://www.shareabitofit.net/ispfpap-n-clglst/

    a) Identify Procedure that starts your installation ISPF environment.

    b) Place the following command statements after the invocation of ISPF
       as depicted below:


       1       10        20        30        40        50        60        70
       ----+----+----+----+----+----+----+----+----+----+----+----+----+----+-
       /********************************************************************/
       /* POST-ISPF Processing                                             */
       /********************************************************************/
       /**********************************************/
       /* Process LOG and LIST Data sets             */
       /**********************************************/
       ISPF CMD(%CLOGLSTX)


    c) When ISPF terminates, CLOG and CLST commands are executed to process
       LOG and LIST data sets per default processing option.


    d) This can be validated by reviewing output and/or data set lists (=3.4)
       depending on default processing option for LOG and LIST data sets.



    You are complete with the CLGLST application installation!


    Note: You can change the processing option for the LOG and/or LIST data set
          per your personal preference by using option 0.2.


Enjoy CLGLST!


======================================================================
* IV. S o f t w a r e   I n v e n t o r y   L i s t                  |
======================================================================

  - SHRABIT.CLGLST.V0R9M03.ASM
   . PRTLST      Print driver
   . PUTLIST     Print a line to ISPF LIST data set

  - SHRABIT.CLGLST.V0R9M03.CLIST
   . README      Dummy member, this is intentional

  - SHRABIT.CLGLST.V0R9M03.CNTL
 $ . $INST00     Define Alias for HLQ CLGLST
 $ . $INST01     Load CNTL data set from distribution tape (HET)
 $ . $INST02     Load other data sets from distribution tape (HET)
 $ . $INST03     Install TSO Parts
 $ . $INST04     Install CLGLST Software
 $ . $INST05     Install ISPF Parts
 $ . $INST40     Install Other Software
 # . $RECVTSO    Receive XMI SEQ to MVS PDSs via TSO RECEIVE
 $ . $RECVXMI    Receive XMI SEQ to MVS PDSs via RECV370
 # . $UP0903     Upgrade to V0R9M03   from   V0R9M02
 $ . DSCLAIMR    Disclaimer
 $ . PREREQS     Required User-mods
 $ . README      Documentation and Installation instructions

  - SHRABIT.CLGLST.V0R9M03.HELP
   . README      Dummy member, this is intentional

  - SHRABIT.CLGLST.V0R9M03.ISPF
   . CLOGIT      CLIST to write log message
   . CLOG        CLIST to process LOG data set
   . C$CLOGIT    IVP CLIST for CLOGIT
   . CLOG00      CLOG00 Messages
   . CLOG01      CLOG01 Messages
   . CLOG02      CLOG02 Messages
   . CLOG03      CLOG03 Messages
   . HLOGV01     LOG Data Set Variables HELP panel
   . PLOGV01     LOG Data Set Variables panel
   . HLLP01      LOG Data Set Disposition HELP panel
   . PLLP01      LOG Data Set Disposition panel
    
 $ . CLSTIT      CLIST to write list message
   . CLST        CLIST to process LIST data set
   . C$CLSTIT    IVP CLIST for CLSTIT
   . CLSTCHR     CLIST LIST Characteristics driver
   . CLST00      CLST00 Messages
   . CLST01      CLST01 Messages
   . CLST02      CLST02 Messages
   . CLST03      CLST03 Messages
   . HLSTV01     LIST Data Set Variables HELP panel
   . PLSTV01     LIST Data Set Variables panel
   . HLLP02      LIST Data Set Disposition HELP panel
   . PLLP02      LIST Data Set Disposition panel
   . HLSTCHR     LIST Data Set Characteristics HELP panel
   . PLSTCHR     LIST Data Set Characteristics panel

   . CLLDFLT     CLIST LOG and LIST Defaults driver
   . CLOGLSTX    CLIST to process LOG and LIST at ISPF termination
   . HLLDFLT     LOG and LIST Defaults HELP panel
   . PLLDFLT     LOG and LIST Defaults panel

  - SHRABIT.CLGLST.V0R9M03.MACLIB
   . README      Dummy member, this is intentional


  - After downloading any other required software, consult provided
    documentation including any configuration steps (if applicable)
    for software and HELP file installation.


 $ - Denotes modified software component for THIS DISTRIBUTION
     relative to prior DISTRIBUTION

 # - Denotes new software component for THIS DISTRIBUTION
     relative to prior DISTRIBUTION





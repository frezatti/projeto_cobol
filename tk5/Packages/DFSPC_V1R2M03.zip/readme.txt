DFSPC for MVS3.8J / Hercules                                               
============================                                               


Date: 03/15/2025  Release V1R2M03
      02/22/2025  Release V1R2M02
      07/01/2024  Release V1R2M01
      06/07/2023  Release V1R2M00
      02/10/2022  Release V1R1M00
      08/10/2020  Release V1R0M00  **INITIAL software distribution

*  Author:  Larry Belmontes Jr.
*           https://ShareABitofIT.net/DFSPC-in-MVS38J
*           Copyright (C) 2020-2025  Larry Belmontes, Jr.


----------------------------------------------------------------------
|    DFSPC        I n s t a l l a t i o n   R e f e r e n c e        |
----------------------------------------------------------------------

   The approach for this installation procedure is to transfer the
distribution content from your personal computing device to MVS with
minimal JCL and to continue the installation procedure using supplied
JCL from the MVS CNTL data set under TSO.

   Below are descriptions of ZIP file content, pre-installation
requirements (notes, credits) and installation steps.

Thanks!
-Larry Belmontes



----------------------------------------------------------------------
|    DFSPC        C h a n g e   H i s t o r y                        |
----------------------------------------------------------------------
*  MM/DD/CCYY Version  Name / Description                                       
*  ---------- -------  -----------------------------------------------          
*  03/15/2025 1.2.03   - Update help content and tutorial variables
*                      - Correct PF10 scroll
*                      - Add new panel with additional dasd indicators
*                                                                               
*  02/22/2025 1.2.02   - Remove MOD2 panel temporary fix due to
*                        screen redesign in v1r2m01
*                      - Resubmit last command via RFIND command
*                      - Update Help and Tutorial Panels
*                                                                               
*  07/01/2024 1.2.01   - Add new view for volume information
*                      - Remove use of GETDTE for date and time
*                        continue to use ISPF Z variables
*                      - UserID and PanelID on line 3
*                      - Add ABOUT command
*                      - Update Help and Tutorial Panels
*                      - Drive MYTUTOR to appropriate help panel
*                                                                               
*  06/07/2023 1.2.00   - Add new panel for volume space utilization
*                      - Allow switching between volume utilization and
*                        volume freespace using PF10/PF11                 
*                      - Add VOL command
*                      - Transition to DFSP00 ISPF messages
*                                                                               
*  02/10/2022 1.1.00   - Add SELECT processing
*                      - Enhance SORT command processing
*                      - Minor programming improvements
*                      - Enhance GETDTE detection
*                      - Add transaction logging
*                                                                               
*  08/10/2020 1.0.00   Larry Belmontes Jr.                                      
*                      - Initial version released to MVS 3.8J                   
*                        hobbyist public domain
*                                                                               
*
======================================================================
* I. C o n t e n t   o f   Z I P   F i l e                           |
======================================================================

o  $INST00.JCL          Define Alias for HLQ in Master Catalog

o  $INST01.JCL          Load CNTL data set from distribution tape

o  $RECVXMI.JCL         RECV370 Receive XMI SEQ to MVS PDSs

o  $RECVTSO.JCL         TSO Receive XMI SEQ to MVS PDSs

o  DFSPC.V1R2M03.HET    Hercules Emulated Tape (HET) multi-file volume
   volser=VS1203        containing software distribution library.

o  DFSPC.V1R2M03.XMI    XMIT file containing software distribution library.

o  DSCLAIMR.TXT         Disclaimer

o  PREREQS.TXT          Required user-mods

o  README.TXT           This File
   Note: See application web page for any updates to readme.txt


Note:   ISPF v2.2+ (ISPF-like product from Wally Mclaughlin) must be     
-----   installed under MVS 3.8J TSO including associated user-mods
        per ISPF Installation Pre-reqs.

Note:   Two user-mods, ZP60014 and ZP60038, are REQUIRED to process
-----   CLIST symbolic variables via the IKJCT441 API on MVS 3.8J before
        using this software.
        More information and download links at:
        http://www.prycroft6.com.au/vs2mods/

Note:   SHRABIT.MACLIB is macro library required to assemble/compile this
-----   software.  A version as-of this distribution is included for
        installation as a pre-requisite.
        More information including current version download link at:
        https://www.shareabitofit.net/SHRABIT-MACLIB-in-MVS-3-8J/

Note:   CLOGIT is an ISPF add-on that performs transaction logging
-----   and must be installed as a pre-requisite.
        Current version can be downloaded and more information at:
        https://www.shareabitofit.net/CLGLST-in-MVS38J/    

Note:   DVTOC is an ISPF add-on that display VTOC information 
-----   and is OPTIONAL for this install if DVTOC will not be used.
        Typically, DVTOC is invoked as a selection option.
        Current version can be downloaded and more information at:
        https://www.shareabitofit.net/DVTOC-in-MVS38J/    

Note:   LBTUTOR is an ISPF add-on that performs tutorial dialogs
-----   and is OPTIONAL for this install if LBTUTOR will not be used.
        Current version can be downloaded and more information at:
        https://www.shareabitofit.net/LBTUTOR-in-MVS38J/    

Note:   DUMAPD is an ISPF add-on that displays UCB information from 
-----   MVS 3.8J.
        OPTIONAL for this install if DUMAPD will not be used.
        Typically, DUMAPD is invoked as a selection option.
        Current version can be downloaded and more information at:
        https://www.shareabitofit.net/DUMAPD-in-MVS38J/

 
======================================================================
* II. P r e - i n s t a l l a t i o n   R e q u i r e m e n t s      |
======================================================================

o  The Master Catalog name for HLQ aliases.

o  The Master Catalog password may be required for some installation
   steps.

o  If loading via tape files, device 480 is utilized.

o  DATASET List after distribution library load for reference purposes:

   DATA-SET-NAME------------------------------- VOLUME ALTRK USTRK ORG FRMT % XT
   SHRABIT.DFPSC.V1R2M03.ASM                    LARB03    20     4 PO  FB  20  1
   SHRABIT.DFPSC.V1R2M03.CLIST                  LARB03     2     1 PO  FB  50  1
   SHRABIT.DFPSC.V1R2M03.CNTL                   LARB03    20     5 PO  FB  25  1
   SHRABIT.DFPSC.V1R2M03.HELP                   LARB03     2     1 PO  FB  50  1
   SHRABIT.DFPSC.V1R2M03.ISPF                   LARB03     5     4 PO  FB  80  1
   SHRABIT.DFPSC.V1R2M03.MACLIB                 LARB03     4     3 PO  FB  75  1
   **END**    TOTALS:      53 TRKS ALLOC        18 TRKS USED       6 EXTENTS


   Confirm the TOTAL track allocation is available on your device.

   Note: A different DASD device type (e.g. 3380) may yield different usage.

o  TSO user-id with sufficient access rights to update SYS2.CMDPROC,
   SYS2.CMDLIB, SYS2.HELP, SYS2.LINKLIB and/or ISPF libraries.

o  For installations with a security system (e.g. RAKF), you MAY need to
   insert additional JOB statement information.

   //         USER=???????,PASSWORD=????????

o  Names of ISPCLIB (Clist), ISPMLIB (Message), ISPLLIB (Load) and/or
   ISPPLIB (Panel) libraries.

o  Download ZIP file to your PC local drive.

o  Unzip the downloaded file into a temp directory on your PC device.

o  Install pre-requisite (if any) software and/or user modifications.

o  JCL from your local device (after unzip) may be edited using
   Notepad or nano (based on you host OS) and submitted via TCP/IP
   sockets reader if your system configuration supports this option.
   This option can replace some copy-paste tasks during installation.
   For more information on submitting JCL to MVS 3.8J, see
   https://www.shareabitofit.net/submitting-jcl-to-mvs-3-8j/

o  For more information on SHRABIT software distribution library, see
   https://www.shareabitofit.net/shrabit-distributions-for-mvs38j/

o  For more information on SHRABIT software installation, see
   https://www.shareabitofit.net/shrabit-installations-for-mvs38j/


======================================================================
* III. I n s t a l l a t i o n   S t e p s                           |
======================================================================

+--------------------------------------------------------------------+
| Step 1. Determine software installation source                     |
+--------------------------------------------------------------------+
|         HET or XMI ?                                               |
+--------------------------------------------------------------------+


    a) Software can be installed from one of two sources, HET or XMI.

       - For tape installation (HET), proceed to STEP 3. ****

         or

       - For XMIT installation (XMI), proceed to next STEP.


+--------------------------------------------------------------------+
| Step 2. Load distribution source from XMI file                     |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.DFPSC.V1R2M03.CNTL($RECVXMI)           |
|         JCL Member: SHRABIT.DFSPC.V1R2M03.CNTL($RECVTSO)           |
+--------------------------------------------------------------------+


______________________________________________________________________
//RECV000A JOB (SYS),'Receive DFSPC XMI',        <-- Review and Modify
//             CLASS=A,MSGCLASS=X,REGION=0M,     <-- Review and Modify
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  JOB: $RECVXMI  Receive Application XMI Files        *
//* *                 using RECV370                        *
//* -------------------------------------------------------*
//RECV     PROC HLQ='SHRABIT.DFSPC',VRM=V1R2M03,TYP=XXXXXXXX,
//             DSPACE='(TRK,(10,05,40))',DDISP='(,CATLG,DELETE)',
//             DUNIT=DISK,DVOLSER=PUB006         <-- Review and Modify
//*
//RECV370  EXEC PGM=RECV370
//RECVLOG  DD  SYSOUT=*
//XMITIN   DD  DISP=SHR,DSN=&&XMIPDS(&TYP)
//SYSPRINT DD  SYSOUT=*
//SYSUT1   DD  DSN=&&SYSUT1,
//   UNIT=SYSALLDA,SPACE=(CYL,(10,05)),DISP=(,DELETE,DELETE) 
//SYSUT2   DD  DSN=&HLQ..&VRM..&TYP,DISP=&DDISP,
//   UNIT=&DUNIT,SPACE=&DSPACE,VOL=SER=&DVOLSER
//SYSIN    DD  DUMMY
//SYSUDUMP DD  SYSOUT=*
//         PEND
//*
//* -------------------------------------------------------*
//* Ensure parent HLQ alias is declared
//* -------------------------------------------------------*
//DEFALIAS EXEC PGM=IDCAMS 
//SYSPRINT DD  SYSOUT=*
//SYSIN    DD  *
 PARM GRAPHICS(CHAIN(SN))
 LISTCAT ALIAS  ENT(SHRABIT)

 /* Review and modify catalog name below */                    
 IF LASTCC NE 0 THEN -
    DEFINE ALIAS(NAME(SHRABIT) RELATE(SYS1.UCAT.MVS))                          
/*                                                                      
//*
//* -------------------------------------------------------*
//* RECV370 DFSPC Software Distribution                     
//* -------------------------------------------------------*
//XMIPDS   EXEC RECV,TYP=XMIPDS,DSPACE='(CYL,(10,05,10),RLSE)' 
//RECV370.XMITIN DD  DISP=SHR,DSN=your.transfer.xmi    <-- XMI File 
//RECV370.SYSUT2   DD  DSN=&&XMIPDS,DISP=(,PASS), 
//   UNIT=SYSDA,SPACE=&DSPACE
//*
//CNTL     EXEC RECV,TYP=CNTL
//RECV370.SYSUT2   DD   DDNAME=&TYP
//CNTL     DD  DSN=&HLQ..&VRM..CNTL,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(20,10,10)),
//             DISP=&DDISP   
//*
//HELP     EXEC RECV,TYP=HELP
//RECV370.SYSUT2   DD   DDNAME=&TYP
//HELP     DD  DSN=&HLQ..&VRM..HELP,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(02,02,02)),
//             DISP=&DDISP   
//*
//CLIST    EXEC RECV,TYP=CLIST
//RECV370.SYSUT2   DD   DDNAME=&TYP
//CLIST    DD  DSN=&HLQ..&VRM..CLIST,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(02,02,02)),
//             DISP=&DDISP   
//*
//ISPF     EXEC RECV,TYP=ISPF
//RECV370.SYSUT2   DD   DDNAME=&TYP
//ISPF     DD  DSN=&HLQ..&VRM..ISPF,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(05,05,10)),
//             DISP=&DDISP   
//*
//ASM      EXEC RECV,TYP=ASM
//RECV370.SYSUT2   DD   DDNAME=&TYP
//ASM      DD  DSN=&HLQ..&VRM..ASM,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(10,10,10)),
//             DISP=&DDISP   
//*
//MACLIB   EXEC RECV,TYP=MACLIB
//RECV370.SYSUT2   DD   DDNAME=&TYP
//MACLIB   DD  DSN=&HLQ..&VRM..MACLIB,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(04,02,02)),
//             DISP=&DDISP   
//
______________________________________________________________________
Figure 1a: $RECVXMI.JCL


______________________________________________________________________
//RECV000B JOB (SYS),'TSO RECEIVE XMI',          <-- Review and Modify
//             CLASS=A,MSGCLASS=X,REGION=0M,     <-- Review and Modify
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  JOB: $RECVTSO  TSO RECEIVE APPLICATION XMI FILES    *
//* *                 for DFSPC software distribution      *
//* -------------------------------------------------------*
//*
//*    This JOB executes two steps:
//*
//*     1) IDCAMS to ensure parent HLQ alias (SHRABIT) is
//*        defined on master catalog
//*        Note: Alias definition bypassed if alias already
//*        ----- defined.
//*
//*     2) Executes TSO in BATCH mode and issues  
//*        TSO RECEIVE commands to load the XMI distribution
//*        library (an XMI SEQ dataset) to a temporary PDS.
//*        Each software PDS is loaded from before deleting
//*        temporary PDS.
//*
//*
//*    This JCL may be modified to suit your installation
//*    needs.                                                
//*
//*    The TSO RECEIVE commands use INdataset, DAtaset, VOL,
//*    and NOPRompt parms.
//*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PROC: PBTSO                                         *
//* *       Batch TSO                                      *
//* *                                                      *
//* -------------------------------------------------------*
//PBTSO    PROC
//STEP01   EXEC PGM=IKJEFT01
//SYSPROC  DD  DISP=SHR,DSN=SYS2.CMDPROC           
//*STEPLIB  DD  DISP=SHR,DSN=SYS2.LINKLIB           
//SYSPRINT DD  SYSOUT=*
//SYSTSPRT DD  SYSOUT=*
//SYSTSIN  DD  DUMMY       Command Line Input
//*
//         PEND
//*
//* -------------------------------------------------------*
//* Ensure parent HLQ alias is declared
//* -------------------------------------------------------*
//DEFALIAS EXEC PGM=IDCAMS 
//SYSPRINT DD  SYSOUT=*
//SYSIN    DD  *
 PARM GRAPHICS(CHAIN(SN))
 LISTCAT ALIAS  ENT(SHRABIT)

 /* Review and modify catalog name below */                    
 IF LASTCC NE 0 THEN -
    DEFINE ALIAS(NAME(SHRABIT) RELATE(SYS1.UCAT.MVS))                          
/*                                                                      
//*
//* -------------------------------------------------------*
//* TSO RECEIVE DFSPC Software Distribution
//* -------------------------------------------------------*
//TSORCV   EXEC PBTSO
//* -------------------------------------------------------*
//* Review and Modify the DSN of the transferred XMI           <-----
//* used in the TSO RECEIVE SYSTSIN DD.                        <-----
//* -------------------------------------------------------*
//STEP01.SYSTSIN DD *
 /* Modify 'SHRABIT.' with your parent HLQ, if different      */    
 /* Modify 'your.transfer.xmi' with transferred XMI SEQ DSN   */    
 /* Modify 'volser' with VOLSER on your system                */    
RECEIVE IN('your.transfer.xmi')          -  
        DA('SHRABIT.DFSPC.V1R2M03.XMIPDS')   -  
        VOL(volser)              NOPROMPT   
 /* Receive CNTL                      */    
RECEIVE IN('SHRABIT.DFSPC.V1R2M03.XMIPDS(CNTL)') -  
        DA('SHRABIT.DFSPC.V1R2M03.CNTL')     -  
        VOL(volser)              NOPROMPT   
 /* Receive HELP                      */    
RECEIVE IN('SHRABIT.DFSPC.V1R2M03.XMIPDS(HELP)') -  
        DA('SHRABIT.DFSPC.V1R2M03.HELP')     -  
        VOL(volser)              NOPROMPT   
 /* Receive CLIST                     */    
RECEIVE IN('SHRABIT.DFSPC.V1R2M03.XMIPDS(CLIST)') -  
        DA('SHRABIT.DFSPC.V1R2M03.CLIST')    -  
        VOL(volser)              NOPROMPT   
 /* Receive ISPF                      */    
RECEIVE IN('SHRABIT.DFSPC.V1R2M03.XMIPDS(ISPF)') -  
        DA('SHRABIT.DFSPC.V1R2M03.ISPF')     -  
        VOL(volser)              NOPROMPT   
 /* Receive ASM                       */    
RECEIVE IN('SHRABIT.DFSPC.V1R2M03.XMIPDS(ASM)') -  
        DA('SHRABIT.DFSPC.V1R2M03.ASM')      -  
        VOL(volser)              NOPROMPT   
 /* Receive MACLIB                    */    
RECEIVE IN('SHRABIT.DFSPC.V1R2M03.XMIPDS(MACLIB)') - 
        DA('SHRABIT.DFSPC.V1R2M03.MACLIB')   -  
        VOL(volser)              NOPROMPT   
 /* Delete XMIPDS                     */    
DELETE  'SHRABIT.DFSPC.V1R2M03.XMIPDS'          
/*
//
______________________________________________________________________
Figure 1b: $RECVTSO.JCL


    a) Transfer DFSPC.V1R2M03.XMI to MVS using your 3270 emulator.

       Make note of the DSN assigned on MVS transfer.

       Use transfer IND$FILE options:

          NEW BLKSIZE=3200 LRECL=80 RECFM=FB
          - or -
          NEW BLKSIZE(3200) LRECL(80) RECFM(FB)

       Ensure the DSN on MVS exists with the correct DCB information:

          ORG=PS BLKSIZE=3200 LRECL=80 RECFM=FB


    b) If using RECV370 to load XMI,
       Copy and paste the $RECVXMI JCL to a PDS member, update JOB
       statement to conform to your installation standard.

          - or -

       If using TSO RECEIVE to load XMI,
       Copy and paste the $RECVTSO JCL to a PDS member, update JOB
       statement to conform to your installation standard.

    c) The first step ensures the HLQ alias is defined and the
       subsequent steps perform the XMI load.

       Review JCL and apply any modifications per your installation
       including the DSN assigned during the transfer above for
       the XMI file.

    d) Submit the job.

    e) Review job output for successful load of the following PDSs:

       SHRABIT.DFPSC.V1R2M03.ASM
       SHRABIT.DFPSC.V1R2M03.CLIST
       SHRABIT.DFPSC.V1R2M03.CNTL
       SHRABIT.DFPSC.V1R2M03.HELP
       SHRABIT.DFPSC.V1R2M03.ISPF
       SHRABIT.DFPSC.V1R2M03.MACLIB

    f) Subsequent installation steps will be submitted from members
       contained in the CNTL data set.

    g) Proceed to STEP 6.   ****


+--------------------------------------------------------------------+
| Step 3. Define Alias for HLQ DFSPC in MVS User Catalog             |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.DFPSC.V1R2M03.CNTL($INST00)            |
+--------------------------------------------------------------------+


______________________________________________________________________
//DFSPC000 JOB (SYS),'Def DFSPC Alias',      <-- Review and Modify 
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  DFSPC for MVS3.8J TSO / Hercules                    *
//* *  JOB: $INST00  Define Alias for parent HLQ SHRABIT   *
//* *  Note: The master catalog password may be required   *
//* -------------------------------------------------------*
//DEFALIAS EXEC PGM=IDCAMS 
//SYSPRINT DD  SYSOUT=*
//SYSIN    DD  *
 PARM GRAPHICS(CHAIN(SN))
 LISTCAT ALIAS  ENT(SHRABIT)

 /* Review and Modify catalog name below */                    
 IF LASTCC NE 0 THEN -
    DEFINE ALIAS(NAME(SHRABIT) RELATE(SYS1.UCAT.MVS))                          
/*                                                                      
//
______________________________________________________________________
Figure 2: $INST00 JCL


    Note: This distribution is installed under the HLQ alias SHRABIT.


    $INST00 bypasses the DEFINE ALIAS action when the alias
    is already defined.

    a) Copy and paste the above JCL to a PDS member, update JOB
       statement to conform to your installation standard.

    b) Submit the job.

    c) Review job output for successful DEFINE ALIAS.

    Note: When $INST00 runs for the first time,
          Job step DEFALIAS returns RC=0004 due to LISTCAT ALIAS function
          completing with condition code of 4 and DEFINE ALIAS function
          completing with condition code of 0.

    Note: When $INST00 runs after the ALIAS is defined,
          Job step DEFALIAS returns RC=0000 due to LISTCAT ALIAS function
          completing with condition code of 0 and DEFINE ALIAS
          function being bypassed.


+--------------------------------------------------------------------+
| Step 4. Load CNTL data set from distribution tape                  |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.DFPSC.V1R2M03.CNTL($INST01)            |
+--------------------------------------------------------------------+


______________________________________________________________________
//DFSPC001 JOB (SYS),'Install CNTL PDS',     <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  DFSPC for MVS3.8J TSO / Hercules                    *
//* *  JOB: $INST01  Load CNTL PDS from distribution tape  *
//* *  Note: Uses tape drive 480                           *
//* -------------------------------------------------------*
//LOADCNTL PROC THLQ=DFSPC,TVOLSER=VS1203,
//   HLQ='SHRABIT.DFSPC',VRM=V1R2M03,
//   DDISP='(,CATLG,DELETE)',
//   TUNIT=480,DVOLSER=PUB006,DUNIT=DISK     <-- Review and Modify
//LOAD001  EXEC PGM=IEBCOPY                                           
//SYSPRINT DD  SYSOUT=*                                              
//INCNTL   DD  DSN=&THLQ..&VRM..CNTL.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(1,SL)                 
//CNTL     DD  DSN=&HLQ..&VRM..CNTL,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(20,10,10)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//         PEND                                                     
//STEP001  EXEC LOADCNTL                     Load CNTL PDS
//SYSIN    DD  *                                                        
    COPY INDD=INCNTL,OUTDD=CNTL 
//
______________________________________________________________________
Figure 3: $INST01 JCL


    a) Before submitting the above job, the distribution tape
       must be made available to MVS by issuing the following
       command from the Hercules console:

       DEVINIT 480 X:\dirname\DFSPC.V1R2M03.HET READONLY=1

       where X:\dirname is the complete path to the location
       of the Hercules Emulated Tape file.

    b) Issue the following command from the MVS console to vary
       device 480 online:

       V 480,ONLINE

    c) Copy and paste the above JCL to a PDS member, update JOB
       statement to conform to your installation standard.

       Review JCL and apply any modifications per your installation.

    d) Submit the job.

    e) Review job output for successful load of the CNTL data set.

    f) Subsequent installation steps will be submitted from members
       contained in the CNTL data set.


+--------------------------------------------------------------------+
| Step 5. Load Other data sets from distribution tape                |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.DFPSC.V1R2M03.CNTL($INST02)            |
+--------------------------------------------------------------------+


______________________________________________________________________
//DFSPC002 JOB (SYS),'Install Other PDSs',   <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  DFSPC for MVS3.8J TSO / Hercules                    *
//* *  JOB: $INST02  Load other PDS from distribution tape *
//* *  Tape Volume:  File 1 - CNTL                         *
//* *                File 2 - CLIST                        *
//* *                File 3 - HELP                         *
//* *                File 4 - ISPF                         *
//* *                File 5 - ASM                          *
//* *                File 6 - MACLIB                       *
//* *  Note: Default TAPE=480, DASD=DISK on PUB006         *
//* -------------------------------------------------------*
//LOADOTHR PROC THLQ=DFSPC,TVOLSER=VS1203,
//   HLQ='SHRABIT.DFSPC',VRM=V1R2M03,
//   DDISP='(,CATLG,DELETE)',
//   TUNIT=480,DVOLSER=PUB006,DUNIT=DISK     <-- Review and Modify
//LOAD02   EXEC PGM=IEBCOPY                                           
//SYSPRINT DD  SYSOUT=*                                              
//INCLIST  DD  DSN=&THLQ..&VRM..CLIST.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(2,SL)                   
//INHELP   DD  DSN=&THLQ..&VRM..HELP.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(3,SL)                   
//INISPF   DD  DSN=&THLQ..&VRM..ISPF.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(4,SL)                   
//INASM    DD  DSN=&THLQ..&VRM..ASM.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(5,SL)                   
//INMACLIB DD  DSN=&THLQ..&VRM..MACLIB.TAPE,UNIT=&TUNIT,
//             VOL=SER=&TVOLSER,DISP=OLD,LABEL=(6,SL)   
//CLIST    DD  DSN=&HLQ..&VRM..CLIST,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(02,02,02)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//HELP     DD  DSN=&HLQ..&VRM..HELP,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(02,02,02)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//ISPF     DD  DSN=&HLQ..&VRM..ISPF,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(05,05,10)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//ASM      DD  DSN=&HLQ..&VRM..ASM,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(10,10,10)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//MACLIB   DD  DSN=&HLQ..&VRM..MACLIB,UNIT=&DUNIT,VOL=SER=&DVOLSER,
//             SPACE=(TRK,(04,02,02)),
//             DISP=&DDISP,  
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3600)
//         PEND                                                         
//*
//STEP001  EXEC LOADOTHR                     Load ALL other PDSs
//SYSIN    DD  *                                                        
    COPY INDD=INCLIST,OUTDD=CLIST
    COPY INDD=INHELP,OUTDD=HELP
    COPY INDD=INISPF,OUTDD=ISPF
    COPY INDD=INASM,OUTDD=ASM
    COPY INDD=INMACLIB,OUTDD=MACLIB
//
______________________________________________________________________
Figure 4: $INST02 JCL


    a) Member $INST02 installs remaining data sets from distribution
       tape.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Before submitting the above job, the distribution tape
       must be made available to MVS by issuing the following
       command from the Hercules console:

       DEVINIT 480 X:\dirname\DFSPC.V1R2M03.HET READONLY=1

       where X:\dirname is the complete path to the location
       of the Hercules Emulated Tape file.

    d) Issue the following command from the MVS console to vary
       device 480 online:

       V 480,ONLINE

    e) Submit the job.

    f) Review job output for successful loads.


+--------------------------------------------------------------------+
| Step 6. FULL or UPGRADE Installation                               |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.DFPSC.V1R2M03.CNTL($UP1203)            |
+--------------------------------------------------------------------+


______________________________________________________________________
//DFSPC00U JOB (SYS),'Upgrade DFSPC',        <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  DFSPC for MVS3.8J TSO / Hercules                    *
//* *                                                      *
//* *  JOB: $UP1203                                        *
//* *       Upgrade DFSPC Software from release V1R2M02    *
//* *                                                      *
//* *  Review JCL before submitting!!                      *
//* -------------------------------------------------------*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PROC: ASMLKED                                       *
//* *       Assembler Link-Edit                            *
//* *                                                      *
//* -------------------------------------------------------*
//ASML     PROC HLQ=WHATHLQ,VRM=VXRXMXX,VIO=VIO,
//             SYSPRM='',
//             ASMPARM='NODECK,LOAD,RENT,TERM,XREF', 
//             LNKPARM='MAP,LIST,LET,RENT,XREF',
//             MBR=WHOWHAT
//*
//ASM      EXEC PGM=IFOX00,
//             PARM='&ASMPARM&SYSPRM' 
//SYSGO    DD  DSN=&&LOADSET,DISP=(MOD,PASS),SPACE=(CYL,(1,1)),
//             UNIT=&VIO,DCB=(DSORG=PS,RECFM=FB,LRECL=80,BLKSIZE=800)
//SYSLIB   DD  DSN=SYS1.MACLIB,DISP=SHR
//         DD  DSN=SYS1.AMODGEN,DISP=SHR
//         DD  DSN=SYS2.MACLIB,DISP=SHR          ** YREG  **
//         DD  DDNAME=PVTMAC                     ** PVTMAC  **
//         DD  DSN=&HLQ..&VRM..MACLIB,DISP=SHR   * myMACLIB **
//PVTMAC   DD  DSN=SYS2.MACLIB,DISP=SHR          * placeholder*
//SYSTERM  DD  SYSOUT=*
//SYSPRINT DD  SYSOUT=*
//SYSPUNCH DD  DSN=NULLFILE
//SYSUT1   DD  UNIT=&VIO,SPACE=(CYL,(6,1))
//SYSUT2   DD  UNIT=&VIO,SPACE=(CYL,(6,1))
//SYSUT3   DD  UNIT=&VIO,SPACE=(CYL,(6,1))
//SYSIN    DD  DSN=&HLQ..&VRM..ASM(&MBR),DISP=SHR <--INPUT
//*
//LKED     EXEC PGM=IEWL,
//             PARM='&LNKPARM',
//             COND=(0,NE,ASM)
//SYSLIN   DD  DSN=&&LOADSET,DISP=(OLD,DELETE)
//         DD  DDNAME=SYSIN
//SYSLMOD  DD  DUMMY
//SYSPRINT DD  SYSOUT=*
//SYSUT1   DD  UNIT=&VIO,SPACE=(CYL,(5,2))
//SYSIN    DD  DUMMY
//*
//         PEND
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PROC: PARTSISPF                                     *
//* *       Copy ISPF Parts                                *
//* *                                                      *
//* -------------------------------------------------------*
//PARTSI   PROC HLQ=MYHLQ,VRM=VXRXMXX,
//             CLIB='XXXXXXXX.ISPCLIB',    
//             MLIB='XXXXXXXX.ISPMLIB',    
//             PLIB='XXXXXXXX.ISPPLIB',   
//             SLIB='XXXXXXXX.ISPSLIB',   
//             TLIB='XXXXXXXX.ISPTLIB'    
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  ISPF Library Member Installation                    *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPF Libraries   *
//* *      - ISPCLIB, ISPMLIB, ISPPLIB, ISPSLIB, ISPTLIB   *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPxLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ISPFLIBS EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//ISPFIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//CLIBOUT  DD  DSN=&CLIB,DISP=SHR
//MLIBOUT  DD  DSN=&MLIB,DISP=SHR
//PLIBOUT  DD  DSN=&PLIB,DISP=SHR
//SLIBOUT  DD  DSN=&SLIB,DISP=SHR
//TLIBOUT  DD  DSN=&TLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//         PEND
//*
//* -------------------------------------------------------*
//* *  Assemble Link-Edit DFSPC to ISPLLIB                 *
//* -------------------------------------------------------*
//DFSPC    EXEC  ASML,HLQ='SHRABIT.DFSPC',VRM=V1R2M03,MBR=DFSPC,
//         PARM.LKED='MAP,LIST,LET,RENT,XREF,REUS,REFR'
//LKED.SYSLMOD DD  DISP=SHR,
//         DSN=xxxxxxxx.ISPLLIB(&MBR)              <--TARGET 
//*
//* -------------------------------------------------------*
//* *  Update ISPF parts for this release distribution     *
//* -------------------------------------------------------*
//* *  Note: Duplicate members are over-written.           *
//* -------------------------------------------------------*
//*
//* *  - Install libraries marked...                       *
//* *    - Search for '<--TARGET'                          *
//* *    - Update install libraries per your               *
//* *      installation standard                           *
//*
//* -------------------------------------------------------*
//ISPFPRTS EXEC PARTSI,HLQ='SHRABIT.DFSPC',VRM=V1R2M03,
//         CLIB='XXXXXXXX.ISPCLIB',                <--TARGET
//         MLIB='XXXXXXXX.ISPMLIB',                <--TARGET
//         PLIB='XXXXXXXX.ISPPLIB',                <--TARGET
//         SLIB='XXXXXXXX.ISPSLIB',                <--TARGET
//         TLIB='XXXXXXXX.ISPTLIB'                 <--TARGET
//SYSIN    DD  *
   COPY INDD=((ISPFIN,R)),OUTDD=CLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
   COPY INDD=((ISPFIN,R)),OUTDD=MLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
   COPY INDD=((ISPFIN,R)),OUTDD=PLIBOUT
   SELECT MEMBER=HDFSPC0
   SELECT MEMBER=HDFSPC1
   SELECT MEMBER=HDFSPC2
   SELECT MEMBER=HDFSPC3
   SELECT MEMBER=PDFSPC0
   SELECT MEMBER=PDFSPC1
   SELECT MEMBER=PDFSPC2
   SELECT MEMBER=PDFSPC3
   SELECT MEMBER=TDFSP001
   SELECT MEMBER=TDFSP002
   SELECT MEMBER=TDFSP003
   SELECT MEMBER=TDFSP004
   SELECT MEMBER=TDFSP005
   SELECT MEMBER=TDFSP006
   SELECT MEMBER=TDFSPA01
   SELECT MEMBER=TDFSPA02
   SELECT MEMBER=TDFSPA03
   SELECT MEMBER=TDFSPA04
   SELECT MEMBER=TDFSPA05
   SELECT MEMBER=TDFSPA06
   SELECT MEMBER=TDFSPB01
   SELECT MEMBER=TDFSPC01
   SELECT MEMBER=TDFSPC02
   SELECT MEMBER=TDFSPC03
   SELECT MEMBER=TDFSPC04
   SELECT MEMBER=TDFSPC05
   SELECT MEMBER=TDFSPZ01
   SELECT MEMBER=TDFSPZ02
   SELECT MEMBER=TDFSPZ03
   SELECT MEMBER=TDFSPZ80
   COPY INDD=((ISPFIN,R)),OUTDD=SLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
   COPY INDD=((ISPFIN,R)),OUTDD=TLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
// 
______________________________________________________________________
Figure 5: $UP1203.JCL  Upgrade from previous version to V1R2M03

    a) If this is the INITIAL software distribution, proceed to STEP 7.

    b) This software may be installed in FULL or UPGRADE from a
       prior version.

    Note:  If the installed software version is NOT the most recent
    -----  PREVIOUS version, perform a FULL install.

    Note:  If the installed software version is customized, a manual
    -----  review and evaluation is suggested to properly incorporate
           customizations into this software distribution before
           proceeding with the installation.

           Refer to the $UPvrmm.JCL members for upgraded software
           components being installed.

    Note:  $UPvrmm.JCL members exist in each software version.
    -----  For example, V1R3M00 software contains $UP1300.JCL
                        to upgrade from previous V1R2M01 distribution.
           For example, V1R2M01 software contains $UP1200.JCL
                        to upgrade from previous V1R1M00 distribution.

    c) If a FULL install of this software distribution is elected
       regardless of previous version installed on your system,
       proceed to STEP 7.

    d) If this is an UPGRADE from the PREVIOUS version,
       execute the below JCL based on current installed version:

       - Upgrading from V1R2M02, use $UP1203.JCL
       - Upgrading from V1R2M01, use $UP1202.JCL
       - Upgrading from V1R2M00, use $UP1201.JCL
       - V1R0M00 is initial release, thus, no updates available!

    e) After upgrade is applied, proceed to validation, STEP 11.


+--------------------------------------------------------------------+
| Step 7. Install TSO parts                                          |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.DFPSC.V1R2M03.CNTL($INST03)            |
+--------------------------------------------------------------------+


______________________________________________________________________
//DFSPC003 JOB (SYS),'Install TSO Parts',    <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  DFSPC for MVS3.8J TSO / Hercules                    *
//* *                                                      *
//* *  JOB: $INST03  Install TSO parts                     *
//* *                                                      *
//* *  Note: Duplicate members are over-written.           *
//* -------------------------------------------------------*
//STEP001  EXEC PGM=IEBCOPY                                           
//SYSPRINT DD  SYSOUT=*                                              
//INCLIST  DD  DSN=SHRABIT.DFSPC.V1R2M03.CLIST,DISP=SHR            
//INHELP   DD  DSN=SHRABIT.DFSPC.V1R2M03.HELP,DISP=SHR             
//OUTCLIST DD  DSN=SYS2.CMDPROC,DISP=SHR                               
//OUTHELP  DD  DSN=SYS2.HELP,DISP=SHR
//SYSIN    DD  *                                                        
    COPY INDD=((INCLIST,R)),OUTDD=OUTCLIST
    SELECT MEMBER=NO#MBR#                    /*dummy entry no mbrs! */
    COPY INDD=((INHELP,R)),OUTDD=OUTHELP
    SELECT MEMBER=NO#MBR#                    /*dummy entry no mbrs! */
/*                                                                  
//
______________________________________________________________________
Figure 6: $INST03 JCL


    a) Member $INST03 installs TSO component(s).

       Note:  If no TSO components are included for this distribution,
       -----  RC = 4 is returned by the corresponding IEBCOPY step.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Submit the job.

    d) Review job output for successful load(s).


+--------------------------------------------------------------------+
| Step 8. Install DFSPC Software                                     |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.DFPSC.V1R2M03.CNTL($INST04)            |
+--------------------------------------------------------------------+


______________________________________________________________________
//DFSPC004 JOB (SYS),'Install DFSPC',        <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  DFSPC for MVS3.8J TSO / Hercules                    *
//* *                                                      *
//* *  JOB: $INST04  Install DFSPC Software                *
//* *                                                      *
//* *  - Install libraries marked...                       *
//* *    - Search for '<--TARGET'                          *
//* *    - Update install libraries per your               *
//* *      installation standard                           *
//* *                                                      *
//* -------------------------------------------------------*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PROC: ASMLKED                                       *
//* *       Assembler Link-Edit                            *
//* *                                                      *
//* -------------------------------------------------------*
//ASML     PROC HLQ=WHATHLQ,VRM=VXRXMXX,VIO=VIO,
//             SYSPRM='',
//             ASMPARM='NODECK,LOAD,RENT,TERM,XREF', 
//             LNKPARM='MAP,LIST,LET,RENT,XREF',
//             MBR=WHOWHAT
//*
//ASM      EXEC PGM=IFOX00,
//             PARM='&ASMPARM&SYSPRM' 
//SYSGO    DD  DSN=&&LOADSET,DISP=(MOD,PASS),SPACE=(CYL,(1,1)),
//             UNIT=&VIO,DCB=(DSORG=PS,RECFM=FB,LRECL=80,BLKSIZE=800)
//SYSLIB   DD  DSN=SYS1.MACLIB,DISP=SHR
//         DD  DSN=SYS1.AMODGEN,DISP=SHR
//         DD  DSN=SYS2.MACLIB,DISP=SHR          ** YREG  **
//         DD  DDNAME=PVTMAC                     ** PVTMAC  **
//         DD  DSN=&HLQ..&VRM..MACLIB,DISP=SHR   * myMACLIB **
//PVTMAC   DD  DSN=SYS2.MACLIB,DISP=SHR          * placeholder*
//SYSTERM  DD  SYSOUT=*
//SYSPRINT DD  SYSOUT=*
//SYSPUNCH DD  DSN=NULLFILE
//SYSUT1   DD  UNIT=&VIO,SPACE=(CYL,(6,1))
//SYSUT2   DD  UNIT=&VIO,SPACE=(CYL,(6,1))
//SYSUT3   DD  UNIT=&VIO,SPACE=(CYL,(6,1))
//SYSIN    DD  DSN=&HLQ..&VRM..ASM(&MBR),DISP=SHR <--INPUT
//*
//LKED     EXEC PGM=IEWL,
//             PARM='&LNKPARM',
//             COND=(0,NE,ASM)
//SYSLIN   DD  DSN=&&LOADSET,DISP=(OLD,DELETE)
//         DD  DDNAME=SYSIN
//SYSLMOD  DD  DUMMY
//SYSPRINT DD  SYSOUT=*
//SYSUT1   DD  UNIT=&VIO,SPACE=(CYL,(5,2))
//SYSIN    DD  DUMMY
//*
//         PEND
//*
//* -------------------------------------------------------*
//* *  Assemble Link-Edit DFSPC to ISPLLIB                 *
//* -------------------------------------------------------*
//DFSPC    EXEC  ASML,HLQ='SHRABIT.DFSPC',VRM=V1R2M03,MBR=DFSPC,
//         PARM.LKED='MAP,LIST,LET,RENT,XREF,REUS,REFR'
//LKED.SYSLMOD DD  DISP=SHR,
//         DSN=XXXXXXXX.ISPLLIB(&MBR)             <--TARGET 
//
______________________________________________________________________
Figure 7: $INST04 JCL


    a) Member $INST04 installs program(s).

       Note:  If no components are included for this distribution,
       -----  an IEFBR14 step is executed.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Submit the job.

    d) Review job output for successful completion.


+--------------------------------------------------------------------+
| Step 9. Install ISPF parts                                         |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.DFPSC.V1R2M03.CNTL($INST05)            |
+--------------------------------------------------------------------+


______________________________________________________________________
//DFSPC005 JOB (SYS),'Install ISPF Parts',   <-- Review and Modify 
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  DFSPC for MVS3.8J TSO / Hercules                    *
//* *                                                      *
//* *  JOB: $INST05  Install ISPF parts                    *
//* *                                                      *
//* *  Note: Duplicate members are over-written.           *
//* *                                                      *
//* *                                                      *
//* *  - Uses ISPF 2.1 product from Wally Mclaughlin       *
//* *  - Install libraries marked...                       *
//* *    - Search for '<--TARGET'                          *
//* *    - Update install libraries per your               *
//* *      installation standard                           *
//* *                                                      *
//* -------------------------------------------------------*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PROC: PARTSISPF                                     *
//* *       Copy ISPF Parts                                *
//* *                                                      *
//* -------------------------------------------------------*
//PARTSI   PROC HLQ=MYHLQ,VRM=VXRXMXX,
//             CLIB='XXXXXXXX.ISPCLIB',    
//             MLIB='XXXXXXXX.ISPMLIB',    
//             PLIB='XXXXXXXX.ISPPLIB',   
//             SLIB='XXXXXXXX.ISPSLIB',   
//             TLIB='XXXXXXXX.ISPTLIB'    
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  CLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPCLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPCLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDCLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//CLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//CLIBOUT  DD  DSN=&CLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  MLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPMLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPMLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDMLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//MLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//MLIBOUT  DD  DSN=&MLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  PLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPPLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPPLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDPLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//PLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//PLIBOUT  DD  DSN=&PLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  SLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPSLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPSLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDSLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//SLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//SLIBOUT  DD  DSN=&SLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//*
//* -------------------------------------------------------*
//* *                                                      *
//* *  TLIB Member Installation                            *
//* *                                                      *
//* *  Suggested Location:                                 *
//* *      DSN defined or concatenated to ISPTLIB DD       *
//* *                                                      *
//* *  Note: If you use a new PDS, it must be defined      *
//* *        before executing this install job AND the     *
//* *        ISPF start-up procedure should include the    *
//* *        new PDS in the ISPTLIB allocation step.       *
//* *                                                      *
//* -------------------------------------------------------*
//ADDTLIB  EXEC PGM=IEBCOPY              
//SYSPRINT DD  SYSOUT=*
//TLIBIN   DD  DSN=&HLQ..&VRM..ISPF,DISP=SHR             
//TLIBOUT  DD  DSN=&TLIB,DISP=SHR
//SYSIN    DD  DUMMY          
//*
//         PEND
//*
//ISPF     EXEC PARTSI,HLQ='SHRABIT.DFSPC',VRM=V1R2M03,
//         CLIB='XXXXXXXX.ISPCLIB',                <--TARGET
//         MLIB='XXXXXXXX.ISPMLIB',                <--TARGET
//         PLIB='XXXXXXXX.ISPPLIB',                <--TARGET
//         SLIB='XXXXXXXX.ISPSLIB',                <--TARGET
//         TLIB='XXXXXXXX.ISPTLIB'                 <--TARGET
//ADDCLIB.SYSIN    DD  *                  CLIB
   COPY INDD=((CLIBIN,R)),OUTDD=CLIBOUT
   SELECT MEMBER=C$DFSPC
//ADDMLIB.SYSIN    DD  *                  MLIB
   COPY INDD=((MLIBIN,R)),OUTDD=MLIBOUT
   SELECT MEMBER=DFSP00
//ADDPLIB.SYSIN    DD  *                  PLIB
   COPY INDD=((PLIBIN,R)),OUTDD=PLIBOUT
   SELECT MEMBER=PDFSPC0
   SELECT MEMBER=HDFSPC0
   SELECT MEMBER=PDFSPC1
   SELECT MEMBER=HDFSPC1
   SELECT MEMBER=PDFSPC2
   SELECT MEMBER=HDFSPC2
   SELECT MEMBER=PDFSPC3
   SELECT MEMBER=HDFSPC3
   SELECT MEMBER=TDFSP100
   SELECT MEMBER=TDFSP001
   SELECT MEMBER=TDFSP002
   SELECT MEMBER=TDFSP003
   SELECT MEMBER=TDFSP004
   SELECT MEMBER=TDFSP005
   SELECT MEMBER=TDFSP006
   SELECT MEMBER=TDFSPA01
   SELECT MEMBER=TDFSPA02
   SELECT MEMBER=TDFSPA03
   SELECT MEMBER=TDFSPA04
   SELECT MEMBER=TDFSPA05
   SELECT MEMBER=TDFSPA06
   SELECT MEMBER=TDFSPB01
   SELECT MEMBER=TDFSPC01
   SELECT MEMBER=TDFSPC02
   SELECT MEMBER=TDFSPC03
   SELECT MEMBER=TDFSPC04
   SELECT MEMBER=TDFSPC05
   SELECT MEMBER=TDFSPZ01
   SELECT MEMBER=TDFSPZ02
   SELECT MEMBER=TDFSPZ03
   SELECT MEMBER=TDFSPZ80
//ADDSLIB.SYSIN    DD  *                  SLIB
   COPY INDD=((SLIBIN,R)),OUTDD=SLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
//ADDTLIB.SYSIN    DD  *                  TLIB
   COPY INDD=((TLIBIN,R)),OUTDD=TLIBOUT
   SELECT MEMBER=NO#MBR#                     /*dummy entry no mbrs! */
//
______________________________________________________________________
Figure 8: $INST05 JCL


    a) Member $INST05 installs ISPF component(s).

       Note:  If no ISPF components are included for this distribution,
       -----  RC = 4 is returned by the corresponding IEBCOPY step.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Review and update DD statements for ISPCLIB (clist),
       ISPMLIB (messages), and/or ISPPLIB (panel) library names.
       The DD statements are tagged with '<--TARGET'.

    d) Submit the job.

    e) Review job output for successful load(s).


+--------------------------------------------------------------------+
| Step 10. Install Other Software                                    |
+--------------------------------------------------------------------+
|         JCL Member: SHRABIT.DFPSC.V1R2M03.CNTL($INST40)            |
+--------------------------------------------------------------------+


______________________________________________________________________
//DFSPC040 JOB (SYS),'Install Other Pgms',   <-- Review and Modify
//         CLASS=A,MSGCLASS=X,               <-- Review and Modify
//         MSGLEVEL=(1,1),NOTIFY=&SYSUID     <-- Review and Modify
//* -------------------------------------------------------*
//* *  DFSPC for MVS3.8J TSO / Hercules                    *
//* *                                                      *
//* *  JOB: $INST40  Install Other Software                *
//* *       Install xxxxxx   Programs                      *
//* *                                                      *
//* *                                                      *
//* -------------------------------------------------------*
//*
//* -------------------------------------------------------*
//* *  IEFBR14                                             *
//* -------------------------------------------------------*
//DUMMY    EXEC PGM=IEFBR14
//SYSPRINT DD   SYSOUT=*
//*
// 
______________________________________________________________________
Figure 9: $INST40 JCL


    a) Member $INST40 installs additional software.

       Note:  If no other software is included for this distribution,
       -----  an IEFBR14 step is executed.

    b) Review and update JOB statement and other JCL to conform to your
       installation standard.

    c) Submit the job.

    d) Review job output for successful completion.


+--------------------------------------------------------------------+
| Step 11. Validate DFSPC                                            |
+--------------------------------------------------------------------+


    a) From the ISPF Main Menu, enter the following command:

       TSO %C$DFSPC

    b) The panel PDFSPC1 is displayed.

________________________________________________________________________________
 07/30/2020.212 12:26:23  -----  DASD Freespace  -----               ROW 1 OF 54
 COMMAND ===>                                                   SCROLL ===> CSR
                                                                        LARRY03
 VOLSER: *ALL*                                                          PDFSPC0
 PF3-End   PF7-Up   PF8-Down   PF10-Left   PF11-Right
                          -----FREE----- -Vol-        2    4    6    8    0 Use
 S  CUU  VOLSER  DEVTYPE  Cyls Trks Exts  Cyls   0----0----0----0----0----0 Pct
 _  244  CBTCAT  3350     0193 0005 0002 00555   ---------------->           65
 _  241  CBT000  3350     0000 0007 0001 00555   -------------------------> 100
 _  242  CBT001  3350     0013 0006 0002 00555   ------------------------>   98
 _  243  CBT002  3350     0036 0011 0001 00555   ----------------------->    94
 _  390  DSHR00  3390     1067 0014 0002 01114   ->                           4
 _  152  HASP00  3330     0092 0000 0001 00404   ------------------->        77
 _  157  HASP01  3330     0093 0000 0001 00404   ------------------->        77
 _  158  HASP02  3330     0093 0000 0001 00404   ------------------->        77
 _  15A  HASP03  3330     0093 0000 0001 00404   ------------------->        77
 _  34A  JES20A  3350     0000 0028 0001 00560   -------------------------> 100
 _  34B  JES20B  3350     0000 0028 0001 00560   -------------------------> 100
 _  34C  JES20C  3350     0000 0028 0001 00560   -------------------------> 100
 _  34D  JES20D  3350     0000 0028 0001 00560   -------------------------> 100
 _  34E  JES20E  3350     0000 0028 0001 00560   -------------------------> 100
 _  34F  JES20F  3350     0000 0028 0001 00560   -------------------------> 100
 _  340  JES200  3350     0000 0000 0000 00560   -------------------------> 100
 _  341  JES201  3350     0000 0023 0001 00560   -------------------------> 100
________________________________________________________________________________
Figure 10a: DFSPC Free Space and Usage Panel


    c) Scroll display using PF7 and PF8.

    d) Scroll left (PF10) or right (PF11) to display next panel.

    e) The panel PDFSPC0 is displayed.

________________________________________________________________________________
 07/30/2020.212 12:26:23  -----  DASD Freespace  -----               ROW 1 OF 54
 COMMAND ===>                                                   SCROLL ===> CSR
                                                                        LARRY03
 VOLSER: *ALL*                                                          PDFSPC0
 PF3-End   PF7-Up   PF8-Down   PF10-Left   PF11-Right
                          -----FREE-----  -LARGEST-    VTOC  Avail  --Volume---
 S  CUU  VOLSER  DEVTYPE  Cyls Trks Exts  Cyls Trks    Trks  DSCBs   Cyls  Trks
 _  244  CBTCAT  3350     0193 0005 0002  0193 0000   00029  01223  00555 16650
 _  241  CBT000  3350     0000 0007 0001  0000 0007   00029  01213  00555 16650
 _  242  CBT001  3350     0013 0006 0002  0013 0000   00029  01012  00555 16650
 _  243  CBT002  3350     0036 0011 0001  0036 0011   00029  01041  00555 16650
 _  390  DSHR00  3390     1067 0014 0002  1067 0000   00015  00745  01114 16710
 _  152  HASP00  3330     0092 0000 0001  0092 0000   00018  00698  00404 07676
 _  157  HASP01  3330     0093 0000 0001  0093 0000   00018  00699  00404 07676
 _  158  HASP02  3330     0093 0000 0001  0093 0000   00018  00699  00404 07676
 _  15A  HASP03  3330     0093 0000 0001  0093 0000   00018  00699  00404 07676
 _  34A  JES20A  3350     0000 0028 0001  0000 0028   00001  00044  00560 16800
 _  34B  JES20B  3350     0000 0028 0001  0000 0028   00001  00044  00560 16800
 _  34C  JES20C  3350     0000 0028 0001  0000 0028   00001  00044  00560 16800
 _  34D  JES20D  3350     0000 0028 0001  0000 0028   00001  00044  00560 16800
 _  34E  JES20E  3350     0000 0028 0001  0000 0028   00001  00044  00560 16800
 _  34F  JES20F  3350     0000 0028 0001  0000 0028   00001  00044  00560 16800
 _  340  JES200  3350     0000 0000 0000  0000 0000   00001  00042  00560 16800
 _  341  JES201  3350     0000 0023 0001  0000 0023   00001  00043  00560 16800
 _  342  JES202  3350     0000 0028 0001  0000 0028   00001  00044  00560 16800
________________________________________________________________________________
Figure 10b: DFSPC Free Space Panel


    f) Scroll display using PF7 and PF8.

    g) Use PF1 to display HELP panel.

    h) Validation is complete.

    i) The following panels can be manually removed from ISPPLIB:
       PDFSPT0
       HDFSPT0
       PDFSPT1
       HDFSPT1
       PDFSPT2
       HDFSPT2


+--------------------------------------------------------------------+
| Step 12. Done                                                      |
+--------------------------------------------------------------------+


    a) Congratulations!  You completed the installation for DFSPC.


+--------------------------------------------------------------------+
| Step 13. Incorporate DFSPC into ISPF menu panel                    |
+--------------------------------------------------------------------+


    a) To integrate DFSPC into your ISPF system, refer to
       SHRABIT.DFPSC.V1R2M03.ASM(DFSPC) for suggested steps in the
       Overview section as a menu item or ISPF command.







Enjoy DFSPC!


======================================================================
* IV. S o f t w a r e   I n v e n t o r y   L i s t                  |
======================================================================

  - SHRABIT.DFPSC.V1R2M03.ASM
 $ . DFSPC       TSO CP Display DASD Free Space Information

  - SHRABIT.DFPSC.V1R2M03.CLIST
   . README      Dummy member, this is intentional

  - SHRABIT.DFPSC.V1R2M03.CNTL
 $ . $INST00     Define Alias for HLQ DFSPC
 $ . $INST01     Load CNTL data set from distribution tape (HET)
 $ . $INST02     Load other data sets from distribution tape (HET)
 $ . $INST03     Install TSO Parts
 $ . $INST04     Install DFSPC Software
 $ . $INST05     Install ISPF Parts
 $ . $INST40     Install Other Software
 $ . $RECVTSO    Receive XMI SEQ to MVS PDSs via TSO RECEIVE
 $ . $RECVXMI    Receive XMI SEQ to MVS PDSs via RECV370
 # . $UP1203     Upgrade to V1R2M03   from   V1R1M02
 $ . DSCLAIMR    Disclaimer
 $ . PREREQS     Required User-mods
 $ . README      Documentation and Installation instructions

  - SHRABIT.DFPSC.V1R2M03.HELP
   . README      Dummy member, this is intentional

  - SHRABIT.DFPSC.V1R2M03.ISPF
   . C$DFSPC     IVP CLIST for DFSPC

   . DFSP00      DFSP00 Messages

 $ . HDFSPC0     DASD Free Space Help panel
 $ . PDFSPC0     DASD Free Space Display panel
 $ . HDFSPC1     DASD Free Space Help Graph panel
 $ . PDFSPC1     DASD Free Space Display Graph panel
 $ . HDFSPC2     DASD Free Space Help panel
 $ . PDFSPC2     DASD Free Space Display panel
 # . HDFSPC3     DASD Free Space Help panel
 # . PDFSPC3     DASD Free Space Display panel

     DFSPC Tutorial Panels
   . TDFSP100    Tutorial Panel Main Menu
 $ . TDFSP001    Tutorial Panel Overview 1
 $ . TDFSP002    Tutorial Panel Overview 2
 $ . TDFSP003    Tutorial Panel Overview 3
 $ . TDFSP004    Tutorial Panel Overview 4
 $ . TDFSP005    Tutorial Panel Overview 5
 # . TDFSP006    Tutorial Panel Overview 6
 $ . TDFSPA01    Tutorial Panel Column Descriptions 1
 $ . TDFSPA02    Tutorial Panel Column Descriptions 2
 $ . TDFSPA03    Tutorial Panel Column Descriptions 3
 $ . TDFSPA04    Tutorial Panel Column Descriptions 4
 $ . TDFSPA05    Tutorial Panel Column Descriptions 5
 # . TDFSPA06    Tutorial Panel Column Descriptions 6
 $ . TDFSPB01    Tutorial Panel Selection Code
 $ . TDFSPC01    Tutorial Panel Optional Parameters 1
 $ . TDFSPC02    Tutorial Panel Optional Parameters 2
 $ . TDFSPC03    Tutorial Panel Optional Parameters 3
 $ . TDFSPC04    Tutorial Panel Optional Parameters 4
 $ . TDFSPC05    Tutorial Panel Optional Parameters 5
 $ . TDFSPZ01    Tutorial Panel Change Log and Limitations 1
 $ . TDFSPZ02    Tutorial Panel Change Log and Limitations 2
 # . TDFSPZ03    Tutorial Panel Change Log and Limitations 3
 $ . TDFSPZ80    Tutorial Panel Change Log and Limitations 3

  - SHRABIT.DFPSC.V1R2M03.MACLIB
   . DVCTBL      Device Table Entries
   . ISPFPL      ISPF Parameter Address List (10)
   . ISPFSRV     ISPF Service keywords
   . ISPFSRVC    ISPF Service keywords (COBOL)
   . LA#ST       Load Address and Store
   . LL#ST       Load Length  and Store
   . LBISPL      Call to ISPLINK (LarryB version)
   . MISCDC      Miscellaneous Constants (i.e. QUOTES)
   . MOVEC       Move VAR at R6, len reflected in R8 (requires MOVEI)
   . MOVEI       Init R6 w/ addr of VAR, init R8 to 0
   . MOVER       Move VAR at R6 until BLANK is found
   . MOVEV       Move VAR at R6
   . RDTECOMA    DateTime comm area
   . RDTECOMC    DateTime comm area (COBOL)
   . RTRIM       Remove trailing spaces
   . SVC78A      SVC78 message area


  - After downloading any other required software, consult provided
    documentation including any configuration steps (if applicable)
    for software and HELP file installation.


 $ - Denotes modified software component for THIS DISTRIBUTION
     relative to prior DISTRIBUTION

 # - Denotes new software component for THIS DISTRIBUTION
     relative to prior DISTRIBUTION




